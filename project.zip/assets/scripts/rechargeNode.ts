// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import PromptFly from "./com/PromptFly";
import EventManager from "./LGQ/EventManager";
import GButton from "./LGQ/GButton";
import Lv_DialogView from "./LGQ/Lv_DialogView";
import GameData from "./LGQ/UserInfo";
import xhrSupport from "./LGQ/xhrSupport";

const { ccclass, property } = cc._decorator;

@ccclass
export default class NewClass extends Lv_DialogView {

    @property(cc.Node)
    btnClose: cc.Node = null;


    @property(cc.Node)
    btnRecharge: cc.Node = null;

    @property(cc.EditBox)
    editBpx: cc.EditBox = null;

    @property(cc.Node)
    box: cc.Node = null;


    @property(cc.Node)
    item: cc.Node = null;

    @property(cc.SpriteFrame)
    coinFrames: cc.SpriteFrame[] = [];

    selectIdx = 0;


    rechargeIdx: number = 0;

    rechargeData: any[] = []

    // LIFE-CYCLE CALLBACKS:

    onLoad() {// 暴露方法到 window 全局，供 iOS 调用
        window["gameCallFromiOS"] = this.gameCallFromiOS.bind(this);
        window["gameCallWithParams"] = this.gameCallWithParams.bind(this);

        if (cc.sys.platform == cc.sys.IPHONE) {
            // 初始化 iOS 内购
            jsb.reflection.callStaticMethod("IAPBridge", "initIAP", null);
            console.log("[IAP] iOS 内购已初始化");
        }
    }

    /**
     * iOS 调用的无参方法
     */
    gameCallFromiOS() {
        console.log("iOS 调用了 Cocos 的无参方法");
        // 业务逻辑：如显示弹窗、播放音效等
    }

    /**
     * iOS 调用的带参数方法（支持多参数、复杂对象）
     */
    gameCallWithParams(receipt_data: string, order_sn: string) {
        console.log("iOS 传参：", receipt_data, order_sn);
        // 业务逻辑：如更新UI、处理数据等
        xhrSupport.RechargeCheck(receipt_data, order_sn, (res) => {
            res = JSON.parse(res);
            if (res.code == 1) {
                GameData.userInfo.score += this.rechargeData[this.rechargeIdx].score
                EventManager.getInstance().sendListener(EventManager.UPDATE_SCORE)
                this.closeView();
            }
            PromptFly.Show(res.msg);

        }, () => { });
    }

    /**
     * （可选）有返回值的方法（iOS 可获取返回值）
     */
    gameCallWithReturn(): string {
        return "Cocos 返回给 iOS 的数据";
    }



    start() {
        this.editBpx.node.active = false;
        GButton.AddClick(this.btnClose, this.closeView, this);
        GButton.AddClick(this.btnRecharge, this.onRechargeClick, this);

        xhrSupport.getRechargeList((res) => {
            res = JSON.parse(res);
            if (res.code == 1) {
                this.rechargeData = res.data.list;
                for (let i = 0; i < res.data.list.length; i++) {
                    let item = cc.instantiate(this.item);
                    item.parent = this.box;
                    item.active = true;
                    item.y = 0;

                    if (i == 0) {
                        item.getChildByName("checkmark").active = true;
                    } else {
                        item.getChildByName("checkmark").active = false;
                    }

                    let idx = i > 2 ? 2 : i;
                    item.getChildByName("coin").getComponent(cc.Sprite).spriteFrame = this.coinFrames[idx];

                    item.getChildByName("prizeLabel").getComponent(cc.Label).string = res.data.list[i].price;
                    item.getChildByName("scoreLabel").getComponent(cc.Label).string = res.data.list[i].score;
                    // item.getComponent("rechargeItem").init(res.data.list[i]);

                    item.on(cc.Node.EventType.TOUCH_END, () => {
                        for (let j = 0; j < this.box.children.length; j++) {
                            this.box.children[j].getChildByName("checkmark").active = false;
                        }
                        item.getChildByName("checkmark").active = true;
                        this.rechargeIdx = i;
                    }, this)
                }
            } else {
                PromptFly.Show(res.msg);
            }
        }, () => { })
    }


    // 点击充值按钮
    onRechargeClick() {
        let productId = this.rechargeData[this.rechargeIdx].id;
        // 映射到 Apple 的产品ID
        let appleProductId = this.getAppleProductId(productId);
        xhrSupport.doRecharge(productId, "applepay", (res) => {
            res = JSON.parse(res);
            if (res.code == 1) {
                this.payment({
                    appleProductId: appleProductId, orderSn: res.data.data.order_sn,
                    success: (data) => {
                        // console.log('data', data);
                    }
                })
            } else {
                PromptFly.Show(res.msg);
            }
        }, () => { })
    }

    /**
     * 支付
     * {
     *   provider: 'wxpay' | alipay, // app 必填
     *   data: '',
     * }
     */
    public payment(data?: any) {
        console.log('ios支付', JSON.stringify(data));
        if (cc.sys.platform == cc.sys.IPHONE) {
            // 获取服务器返回的数据
            const orderSn = data.orderSn;           // 订单号
            const appleProductId = data.appleProductId;
            console.log(`[IAP] 开始内购: 订单=${orderSn}, Apple产品=${appleProductId}`);
            // 调用 iOS 原生方法发起购买
            jsb.reflection.callStaticMethod(
                "IAPBridge",
                "purchaseProduct:orderSn:",
                appleProductId,    // Apple 商品 ID
                orderSn            // 订单号
            );
        }
        else if (cc.sys.platform == cc.sys.BYTEDANCE_GAME) {
        } else if (cc.sys.platform == cc.sys.WECHAT_GAME) {
        } else {
            if (data?.success) data.success();
        }
    }


    // 3️⃣ Apple 产品 ID 映射表
    private getAppleProductId(productId: string): string {
        // 将你服务器的产品ID映射到 App Store Connect 的商品ID
        const productMap = {
            '1': 'com.gameios.bztcs.app.gold01',      // 10金币
            '2': 'com.gameios.bztcs.app.gold02',      // 60金币
            '3': 'com.gameios.bztcs.app.gold03',     // 120金币
            '4': 'com.gameios.bztcs.app.gold04',     // 580金币
        };

        return productMap[productId] || 'com.yourcompany.yourapp.default';
    }


    // update (dt) {}
}
