"use strict";
cc._RF.push(module, '9be160P2HNOoJSCzadk5ruD', 'Game');
// scripts/Game.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var CameraFollow_1 = require("./CameraFollow");
var MsgCfg_1 = require("./com/MsgCfg");
var PromptFly_1 = require("./com/PromptFly");
var head_1 = require("./head");
var GButton_1 = require("./LGQ/GButton");
var ResManager_1 = require("./LGQ/ResManager");
var UserInfo_1 = require("./LGQ/UserInfo");
var Utils_1 = require("./LGQ/Utils");
var xhrSupport_1 = require("./LGQ/xhrSupport");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Game = /** @class */ (function (_super) {
    __extends(Game, _super);
    function Game() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.timeNode = null;
        _this.ndTime = null;
        // @property(cc.Node)
        // btnPause: cc.Node = null;
        _this.player = null;
        _this.joyStickBtn = null;
        _this.ndJoyStick = null;
        _this.ndCamera = null;
        _this.lblScore = null;
        _this.ndEffect = null;
        _this.btnAddSpeed = null;
        _this.btnMS = null;
        _this.btnSet = null;
        // @property(cc.Node)
        // btnMusic: cc.Node = null;
        // @property(cc.Node)
        // ndKai: cc.Node = null;
        // @property(cc.Node)
        // ndGuan: cc.Node = null;
        _this.bgPlus = null;
        _this.bgSp = null;
        _this.bgSpFrames = [];
        _this.isPause = false;
        _this.time = 3;
        _this.toolsData = [];
        _this.score = 0;
        return _this;
        // onClickMusic() {
        //     let musicData = UserInfo.getItem(UserCfg.MusicData, false);
        //     if (!musicData) {
        //         let data = {
        //             isMusic: true,
        //             isEffect: true
        //         }
        //         musicData = data;
        //         UserInfo.setItem(UserCfg.MusicData, musicData, false);
        //     }
        //     musicData.isMusic = !musicData.isMusic;
        //     musicData.isEffect = !musicData.isEffect;
        //     if (musicData.isMusic) {//播放音乐
        //         AudioManager.resumeMusic();
        //     }
        //     else {//停止音乐
        //         AudioManager.pauseMusic();
        //     }
        //     AudioManager.updateMusic(musicData);
        //     this.ndKai.active = musicData.isMusic;
        //     this.ndGuan.active = !musicData.isMusic;
        //     UserInfo.setItem(UserCfg.MusicData, musicData, false);
        // }
        // update (dt) {}
    }
    Game_1 = Game;
    Game.prototype.onLoad = function () {
        Game_1.I = this;
        cc.debug.setDisplayStats(false);
        var manager = cc.director.getCollisionManager();
        manager.enabled = true;
        // manager.enabledDebugDraw = true;
        // manager.enabledDrawBoundingBox = true;
        // touch event
        this.joyStickBtn.on('touchstart', this.onTouchStart, this);
        this.joyStickBtn.on('touchmove', this.onTouchMove, this);
        this.joyStickBtn.on('touchend', this.onTouchEnd, this);
        this.joyStickBtn.on('touchcancel', this.onTouchCancel, this);
        Utils_1.Utils.addInnerMsg(MsgCfg_1.InnerMsg.gameResume, this, this.gameResume);
        this.bgSp.spriteFrame = this.bgSpFrames[UserInfo_1.default.sceneIdx];
        this.bgPlus.active = UserInfo_1.default.sceneIdx == 0;
        GButton_1.default.AddClick(this.btnSet, function () {
            Utils_1.Utils.openBundleView('pb/setNode', "game");
        }, this);
    };
    Game.prototype.onDestroy = function () {
        // touch event
        this.joyStickBtn.off('touchstart', this.onTouchStart, this);
        this.joyStickBtn.off('touchmove', this.onTouchMove, this);
        this.joyStickBtn.off('touchend', this.onTouchEnd, this);
        this.joyStickBtn.off('touchcancel', this.onTouchCancel, this);
        Utils_1.Utils.removeInnerMsg(MsgCfg_1.InnerMsg.gameResume, this, this.gameResume);
    };
    Game.prototype.onTouchStart = function (event) {
        // when touch starts, set joyStickBtn's position 
        var pos = this.ndJoyStick.convertToNodeSpaceAR(event.getLocation());
        if (Utils_1.Utils.getDistance(cc.v2(0, 0), pos) > 80) {
            var angle = Math.atan2(pos.y, pos.x);
            // angle = angle * 180 / Math.PI;
            pos.x = 80 * Math.cos(angle);
            pos.y = 80 * Math.sin(angle);
        }
        this.ndJoyStick.setPosition(pos);
    };
    Game.prototype.onTouchMove = function (event) {
        // constantly change joyStickBtn's position
        // let posDelta = event.getDelta();
        // this.joyStickBtn.setPosition(this.joyStickBtn.position.add(posDelta));
        // this.dir = this.joyStickBtn.position.normalize();
        var posDelta = event.getDelta();
        var pos = this.ndJoyStick.position.add(posDelta);
        if (Utils_1.Utils.getDistance(cc.v2(0, 0), pos) > 80) {
            var angle = Math.atan2(pos.y, pos.x);
            // angle = angle * 180 / Math.PI;
            pos.x = 80 * Math.cos(angle);
            pos.y = 80 * Math.sin(angle);
        }
        this.ndJoyStick.setPosition(pos);
        // get direction
        var dir = this.ndJoyStick.position.normalize();
        this.player.getComponent("head").dir = dir;
    };
    Game.prototype.onTouchEnd = function (event) {
        // reset
        this.ndJoyStick.setPosition(cc.v2(0, 0));
    };
    Game.prototype.onTouchCancel = function (event) {
        // reset
        this.ndJoyStick.setPosition(cc.v2(0, 0));
    };
    Game.prototype.start = function () {
        // let musicData = UserInfo.getItem(UserCfg.MusicData, false);
        // if (!musicData) {
        //     let data = {
        //         isMusic: true,
        //         isEffect: true
        //     }
        //     musicData = data;
        var _this = this;
        //     UserInfo.setItem(UserCfg.MusicData, musicData, false);
        // }
        // let musicData = {
        //     isMusic: true,
        //     isEffect: true
        // }
        // AudioManager.updateMusic(musicData);
        // this.ndKai.active = musicData.isMusic;
        // this.ndGuan.active = !musicData.isMusic;
        // AudioManager.playMusic("gameBGM");
        UserInfo_1.default.Game = this;
        this.ndCamera.getComponent(CameraFollow_1.default).target = this.player;
        this.score = 0;
        this.time = 3;
        this.timeNode.active = true;
        this.ndTime.active = false;
        this.isPause = true;
        this.setTime();
        this.doPause();
        // GButton.AddClick(this.btnPause, () => {
        //     this.isPause = true;
        //     this.player.getComponent(head).gamePause();
        //     Utils.openBundleView("pb/PauseNode")
        // }, this);
        GButton_1.default.AddClick(this.btnAddSpeed, function () {
            if (_this.toolsData[1].use_status == 0) { //不可用
                _this.doPause();
                var call = function () {
                    xhrSupport_1.default.buyTool(_this.toolsData[1].id, function (res) {
                        res = JSON.parse(res);
                        if (res.code == 1) {
                            _this.toolsData[1].use_status = 1;
                            _this.btnAddSpeed.children[0].active = false;
                        }
                        else {
                            PromptFly_1.default.Show(res.msg);
                        }
                    }, function () { });
                };
                Utils_1.Utils.openBundleView('pb/commonTipNode', [_this.toolsData[1].price, "是否花费", "购买加速道具", call]);
            }
            else { //可用
                if (!UserInfo_1.default.accelerate) {
                    xhrSupport_1.default.useTool(_this.toolsData[1].id, function (res) {
                        res = JSON.parse(res);
                        if (res.code == 1) {
                            // GameData.userInfo.score -= 10
                            _this.useToolSpeed();
                        }
                        else {
                            PromptFly_1.default.Show(res.msg);
                        }
                    }, function () { });
                }
                else {
                    // this.player.getComponent(head).addSpeed();
                }
            }
        }, this);
        // GButton.AddClick(this.btnAddSpeed, () => {
        //     this.player.getComponent(head).resumeSpeed();
        // }, this, () => {
        //     this.player.getComponent(head).addSpeed();
        // }, null, () => {
        //     this.player.getComponent(head).resumeSpeed();
        // });
        xhrSupport_1.default.getToolList(1, 2, function (res) {
            res = JSON.parse(res);
            if (res.code == 1) {
                _this.toolsData = res.data.list;
                _this.btnMS.children[0].active = res.data.list[0].use_status == 0;
                _this.btnAddSpeed.children[0].active = res.data.list[1].use_status == 0;
            }
        }, function () { });
        GButton_1.default.AddClick(this.btnMS, function () {
            if (_this.toolsData[0].use_status == 0) { //不可用
                _this.doPause();
                var call = function () {
                    _this.gameResume();
                    xhrSupport_1.default.buyTool(_this.toolsData[0].id, function (res) {
                        res = JSON.parse(res);
                        if (res.code == 1) {
                            _this.toolsData[0].use_status = 1;
                            _this.btnMS.children[0].active = false;
                        }
                        else {
                            PromptFly_1.default.Show(res.msg);
                        }
                    }, function () { });
                };
                Utils_1.Utils.openBundleView('pb/commonTipNode', [_this.toolsData[0].price, "是否花费", "购买无敌道具", call]);
            }
            else { //可用
                if (!UserInfo_1.default.invincible) {
                    xhrSupport_1.default.useTool(_this.toolsData[0].id, function (res) {
                        res = JSON.parse(res);
                        if (res.code == 1) {
                            // GameData.userInfo.score -= 10
                            _this.useToolMS();
                        }
                        else {
                            PromptFly_1.default.Show(res.msg);
                        }
                    }, function () { });
                }
            }
        }, this);
        // GButton.AddClick(this.btnMusic, this.onClickMusic, this);
    };
    Game.prototype.useToolMS = function () {
        var _this = this;
        PromptFly_1.default.Show("获取10S中的免伤效果");
        UserInfo_1.default.invincible = true;
        // this.player.opacity = 120
        this.btnMS.children[0].active = true;
        this.btnMS.children[0].getComponent(cc.Sprite).fillRange = 0;
        cc.tween(this.btnMS.children[0].getComponent(cc.Sprite)).to(10, { fillRange: 1 }).start();
        this.scheduleOnce(function () {
            UserInfo_1.default.invincible = false;
            // this.player.stopAllActions();
            // this.player.opacity = 255
            _this.toolsData[0].use_status = 0;
        }, 10);
    };
    Game.prototype.useToolSpeed = function () {
        var _this = this;
        this.player.getComponent(head_1.default).addSpeed();
        PromptFly_1.default.Show("获取10S的加速效果");
        UserInfo_1.default.accelerate = true;
        // this.player.opacity = 120
        this.btnAddSpeed.children[0].active = true;
        this.btnAddSpeed.children[0].getComponent(cc.Sprite).fillRange = 0;
        cc.tween(this.btnAddSpeed.children[0].getComponent(cc.Sprite)).to(10, { fillRange: 1 }).start();
        this.scheduleOnce(function () {
            UserInfo_1.default.accelerate = false;
            _this.player.stopAllActions();
            // this.player.opacity = 255
            // this.toolsData[1].use_status = 0
            _this.player.getComponent(head_1.default).resumeSpeed();
        }, 10);
    };
    Game.prototype.doPause = function () {
        this.isPause = true;
        this.player.getComponent(head_1.default).gamePause();
    };
    Game.prototype.gameResume = function () {
        this.isPause = false;
        this.player.getComponent(head_1.default).gameResume();
    };
    Game.prototype.quitBySet = function () {
        var _this = this;
        this.doPause();
        xhrSupport_1.default.endGame(UserInfo_1.default.sceneId, this.score, 1, function (res) {
            res = JSON.parse(res);
            if (res.code == 1) {
                Utils_1.Utils.openBundleView('pb/trunUI', _this.score);
            }
            else {
                PromptFly_1.default.Show(res.msg);
            }
        }, function () { });
    };
    Game.prototype.setTime = function () {
        var _this = this;
        cc.tween(this.ndTime).stop();
        ResManager_1.default.I.changeBundlePic(this.ndTime, "res/game/" + this.time, function () {
            _this.ndTime.active = true;
            _this.ndTime.scale = 2;
            cc.tween(_this.ndTime)
                .to(0.9, { scale: 1 })
                .delay(0.1)
                .call(function () {
                _this.time--;
                if (_this.time >= 0) {
                    _this.setTime();
                }
                else {
                    _this.timeNode.active = false;
                    // this.isPause = false;
                    _this.gameResume();
                    var dir = new cc.Vec3(1, 0, 0).normalize();
                    _this.player.getComponent("head").dir = dir;
                }
            }).start();
            // this.ndTime.runAction(cc.sequence(cc.scaleTo(0.9, 1), cc.delayTime(0.1), cc.callFunc(() => {
            //     // this.ndTime.active = false;
            //     // this.ndTime.getComponent(cc.Sprite).spriteFrame = null;
            //     this.time--;
            //     if (this.time >= 0) {
            //         this.setTime();
            //     } else {
            //         this.timeNode.active = false;
            //     }
            // })));
        });
    };
    Game.prototype.addScore = function (score) {
        this.score += score;
        this.lblScore.string = this.score + '';
        if (score == 20) {
            this.setEffect();
        }
    };
    Game.prototype.setEffect = function () {
        var _this = this;
        this.ndEffect.active = true;
        cc.tween(this.ndEffect)
            .to(0.5, { scale: 1.5 })
            .delay(0.3)
            .call(function () {
            _this.ndEffect.active = false;
        })
            .start();
    };
    Game.prototype.setGameOver = function () {
        var _this = this;
        xhrSupport_1.default.endGame(UserInfo_1.default.sceneId, this.score, 1, function (res) {
            res = JSON.parse(res);
            if (res.code == 1) {
                _this.doPause();
                Utils_1.Utils.openBundleView('pb/GameOver', _this.score);
            }
            else {
                // PromptFly.Show(res.msg);
            }
        }, function () { });
        // setTimeout(() => {
        // }, 500);
    };
    var Game_1;
    // @property(cc.Node)
    // headIcon: cc.Node = null;
    Game.I = null;
    __decorate([
        property(cc.Node)
    ], Game.prototype, "timeNode", void 0);
    __decorate([
        property(cc.Node)
    ], Game.prototype, "ndTime", void 0);
    __decorate([
        property(cc.Node)
    ], Game.prototype, "player", void 0);
    __decorate([
        property(cc.Node)
    ], Game.prototype, "joyStickBtn", void 0);
    __decorate([
        property(cc.Node)
    ], Game.prototype, "ndJoyStick", void 0);
    __decorate([
        property(cc.Node)
    ], Game.prototype, "ndCamera", void 0);
    __decorate([
        property(cc.Label)
    ], Game.prototype, "lblScore", void 0);
    __decorate([
        property(cc.Node)
    ], Game.prototype, "ndEffect", void 0);
    __decorate([
        property(cc.Node)
    ], Game.prototype, "btnAddSpeed", void 0);
    __decorate([
        property(cc.Node)
    ], Game.prototype, "btnMS", void 0);
    __decorate([
        property(cc.Node)
    ], Game.prototype, "btnSet", void 0);
    __decorate([
        property(cc.Node)
    ], Game.prototype, "bgPlus", void 0);
    __decorate([
        property(cc.Sprite)
    ], Game.prototype, "bgSp", void 0);
    __decorate([
        property(cc.SpriteFrame)
    ], Game.prototype, "bgSpFrames", void 0);
    Game = Game_1 = __decorate([
        ccclass
    ], Game);
    return Game;
}(cc.Component));
exports.default = Game;

cc._RF.pop();