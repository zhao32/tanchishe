"use strict";
cc._RF.push(module, 'f905331NoxMuJBvBd/NO5J7', 'SdkUtils');
// scripts/LGQ/SdkUtils.ts

"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var SdkUtils = /** @class */ (function () {
    function SdkUtils() {
    }
    SdkUtils_1 = SdkUtils;
    SdkUtils.init = function () {
        if (cc.sys.platform == cc.sys.WECHAT_GAME) {
            //@ts-ignore
            // wx.cloud.init();
            //@ts-ignore
            this.wechatSysInfo = wx.getSystemInfoSync();
        }
    };
    SdkUtils.initShareMenu = function () {
        if (cc.sys.platform == cc.sys.WECHAT_GAME) {
            try {
                //@ts-ignore
                wx.showShareMenu({
                    withShareTicket: true,
                    menus: ['shareAppMessage', 'shareTimeline'],
                    success: function () { },
                    fail: function () { },
                    complete: function () { }
                });
                //@ts-ignore
                wx.onShareAppMessage(function () {
                    return {
                        // title: '来一起玩爆爽的弹珠',
                        success: function () { },
                        fail: function () { }
                    };
                });
            }
            catch (err) {
                console.log("set share faild: " + err);
            }
        }
        else if (cc.sys.platform == cc.sys.BYTEDANCE_GAME) {
            tt.showShareMenu({
                menus: ['shareAppMessage'],
            });
            tt.onShareAppMessage(function () {
                return {
                // title: '来一起玩爆爽的弹珠',
                };
            });
        }
    };
    SdkUtils.shareGame = function () {
        if (cc.sys.platform == cc.sys.WECHAT_GAME) {
            try {
                //@ts-ignore
                wx.shareAppMessage({
                // title: '快来一起弹弹球，好玩得很！'
                });
            }
            catch (err) {
                cc.log("share faild: " + err);
            }
        }
        else if (cc.sys.platform == cc.sys.BYTEDANCE_GAME) {
            console.log("分享");
            try {
                //@ts-ignore
                tt.shareAppMessage({
                // title: '快来一起弹弹球，好玩得很！'
                });
            }
            catch (err) {
                cc.log("share faild: " + err);
            }
        }
    };
    /**
     *
     * @param text message in string
     * @param duration seconds
     */
    SdkUtils.showToast = function (text, duration) {
        if (duration === void 0) { duration = 3; }
        if (cc.sys.platform == cc.sys.WECHAT_GAME) {
            // @ts-ignore
            wx.showToast({
                title: text,
                icon: 'success',
                duration: duration * 1000
            });
        }
        else if (cc.sys.platform == cc.sys.BYTEDANCE_GAME) {
            tt.showToast({
                title: text,
                icon: 'success',
                duration: duration * 1000
            });
        }
    };
    SdkUtils.getUserInfo = function (func, createBtnFunc) {
        this.init();
        if (cc.sys.platform == cc.sys.WECHAT_GAME) {
            var windowWidth_1 = this.wechatSysInfo.windowWidth; //获取像素size
            var windowHeight_1 = this.wechatSysInfo.windowHeight;
            wx.getSetting({
                success: function (res) {
                    if (res.authSetting['scope.userInfo'] == true) {
                        // 已经授权，可以直接调用 getUserInfo 获取头像昵称
                        wx.getUserInfo({
                            success: function (res) {
                                console.log("用户信息:", res.userInfo);
                                func && func(res.userInfo);
                            }
                        });
                    }
                    else {
                        // 否则，先通过 wx.createUserInfoButton 接口发起授权
                        var button_1 = wx.createUserInfoButton({
                            type: '',
                            text: '',
                            style: {
                                left: 0,
                                top: 0,
                                width: windowWidth_1,
                                height: windowHeight_1,
                            }
                        });
                        button_1.onTap(function (res) {
                            // 用户同意授权后回调，通过回调可获取用户头像昵称信息
                            console.log("用户授权：", res);
                            button_1.destroy();
                            func && func(res.userInfo);
                        });
                        createBtnFunc && createBtnFunc();
                    }
                }
            });
        }
        else if (cc.sys.platform == cc.sys.BYTEDANCE_GAME) {
            // 获取用户信息
            tt.getSetting({
                success: function (res) {
                    if (res.authSetting['scope.userInfo']) {
                        // 已经授权，可以直接调用 getUserInfo 获取头像昵称
                        tt.getUserInfo({
                            success: function (res) {
                                console.log("getUserInfo \u8C03\u7528\u6210\u529F", res.userInfo, res.encryptedData, res.iv, res.signature);
                                func && func(res.userInfo);
                            },
                            fail: function (res) {
                                console.log("getUserInfo \u8C03\u7528\u5931\u8D25", res.errMsg);
                            },
                        });
                    }
                    else {
                        // 否则发起授权
                        tt.authorize({
                            scope: "scope.userInfo",
                            success: function (res) {
                                if (res.data["scope.userInfo"] == 'ok') {
                                    console.log("\u6388\u6743\u6210\u529F", res.data);
                                    tt.getUserInfo({
                                        success: function (res) {
                                            console.log("getUserInfo \u8C03\u7528\u6210\u529F", res.userInfo, res.encryptedData, res.iv, res.signature);
                                            func && func(res.userInfo);
                                        },
                                        fail: function (res) {
                                            console.log("getUserInfo \u8C03\u7528\u5931\u8D25", res.errMsg);
                                        },
                                    });
                                }
                            },
                            fail: function (res) {
                                console.log("\u6388\u6743\u5931\u8D25", res.errMsg);
                            }
                        });
                    }
                }
            });
        }
    };
    SdkUtils.login = function (success) {
        if (cc.sys.platform == cc.sys.WECHAT_GAME) {
            wx.login({
                success: function (res) {
                    if (res.code) {
                        //发起网络请求
                        console.log('登录成功！' + res.code);
                        success && success(res.code);
                    }
                    else {
                        console.log('登录失败！' + res.errMsg);
                    }
                }
            });
        }
        else if (cc.sys.platform == cc.sys.BYTEDANCE_GAME) {
            tt.login({
                success: function (res) {
                    console.log("登录成功", res);
                    success && success(res.code);
                },
            });
        }
    };
    //震动
    SdkUtils.vibrate = function () {
        if (cc.sys.platform == cc.sys.WECHAT_GAME) {
            wx.vibrateLong({
                // type: "medium",
                success: function (res) {
                    console.log('震动成功！');
                }
            });
        }
        else if (cc.sys.platform == cc.sys.BYTEDANCE_GAME) {
            tt.vibrateLong({
                success: function (res) {
                    console.log('震动成功！');
                },
            });
        }
    };
    SdkUtils.setCallback = function (event, callback) {
        this.callback.set(event, callback);
    };
    SdkUtils.getCallback = function (event) {
        return this.callback.has(event) ? this.callback.get(event) : null;
    };
    SdkUtils.showAdVideo = function (data) {
        var event = 'rewardedVideoAd';
        if (cc.sys.platform == cc.sys.BYTEDANCE_GAME) {
            if (!SdkUtils_1.asId.tt) {
                if (data === null || data === void 0 ? void 0 : data.success)
                    data.success();
            }
            else {
                if (this._adVideo == null) {
                    this._adVideo = tt.createRewardedVideoAd({ adUnitId: SdkUtils_1.asId.tt });
                    this._adVideo.onClose(this.onRewardedClose.bind(this));
                    this._adVideo.onError(this.onError.bind(this, event));
                }
                this.setCallback(event, { success: data === null || data === void 0 ? void 0 : data.success, rewarded: data === null || data === void 0 ? void 0 : data.rewarded, fail: data === null || data === void 0 ? void 0 : data.fail });
                this._adVideo.show();
            }
        }
        else if (cc.sys.platform == cc.sys.WECHAT_GAME) {
            if (!SdkUtils_1.asId.wx) {
                if (data === null || data === void 0 ? void 0 : data.success)
                    data.success();
            }
            else {
                if (this._adVideo == null) {
                    this._adVideo = wx.createRewardedVideoAd({ adUnitId: SdkUtils_1.asId.wx });
                    this._adVideo.onClose(this.onRewardedClose.bind(this));
                    this._adVideo.onError(this.onError.bind(this, event));
                }
                this.setCallback(event, { success: data === null || data === void 0 ? void 0 : data.success, rewarded: data === null || data === void 0 ? void 0 : data.rewarded, fail: data === null || data === void 0 ? void 0 : data.fail });
                this._adVideo.show();
            }
        }
        else {
            if (data === null || data === void 0 ? void 0 : data.success)
                data.success();
        }
    };
    SdkUtils.onRewardedClose = function (res) {
        var _a, _b;
        console.log('onRewardedClose', res);
        var event = 'rewardedVideoAd';
        if (res.isEnded && ((_a = this.getCallback(event)) === null || _a === void 0 ? void 0 : _a.success))
            this.getCallback(event).success();
        else if ((_b = this.getCallback(event)) === null || _b === void 0 ? void 0 : _b.fail)
            this.getCallback(event).fail();
    };
    SdkUtils.onError = function (event, res) {
        var _a;
        console.log('onError event', event);
        console.log('onError msg', res);
        if ((_a = this.getCallback(event)) === null || _a === void 0 ? void 0 : _a.fail)
            this.callback.get(event).fail();
    };
    var SdkUtils_1;
    SdkUtils.wechatSysInfo = null;
    SdkUtils._adVideo = null;
    SdkUtils.asId = {
        wx: '',
        tt: ''
    };
    SdkUtils.callback = new Map();
    SdkUtils = SdkUtils_1 = __decorate([
        ccclass
    ], SdkUtils);
    return SdkUtils;
}());
exports.default = SdkUtils;

cc._RF.pop();