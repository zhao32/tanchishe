"use strict";
cc._RF.push(module, 'eb5d43Qk2xA67mMCdwrXz/N', 'loginNode');
// scripts/loginNode.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var PromptFly_1 = require("./com/PromptFly");
var GButton_1 = require("./LGQ/GButton");
var Lv_DialogView_1 = require("./LGQ/Lv_DialogView");
var UserInfo_1 = require("./LGQ/UserInfo");
var Utils_1 = require("./LGQ/Utils");
var xhrSupport_1 = require("./LGQ/xhrSupport");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var loginNode = /** @class */ (function (_super) {
    __extends(loginNode, _super);
    function loginNode() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.btnClose = null;
        _this.accountEidt = null;
        _this.codeEidt = null;
        _this.checkToggle = null;
        _this.btnRegister = null;
        _this.btnRestPwd = null;
        _this.btnLogin = null;
        return _this;
        // update (dt) {}
    }
    // LIFE-CYCLE CALLBACKS:
    // onLoad () {}
    loginNode.prototype.start = function () {
        GButton_1.default.AddClick(this.btnClose, this.onClose, this);
        GButton_1.default.AddClick(this.btnRegister, this.onRegister, this);
        GButton_1.default.AddClick(this.btnRestPwd, this.onResetPwd, this);
        GButton_1.default.AddClick(this.btnLogin, this.onLoginHandler, this);
        GButton_1.default.AddClick(this.btnClose, this.onClose, this);
    };
    loginNode.prototype.onResetPwd = function () {
        Utils_1.Utils.openBundleView("pb/getPwdNode", "找回");
    };
    loginNode.prototype.onRegister = function () {
        Utils_1.Utils.openBundleView('pb/registerNode');
    };
    loginNode.prototype.onProtocol = function (target, data) {
        Utils_1.Utils.openBundleView('pb/protrolNode', data);
    };
    loginNode.prototype.onClose = function () {
        this.closeView();
    };
    loginNode.prototype.onLoginHandler = function () {
        var _this = this;
        if (this.accountEidt.string == '' || this.codeEidt.string == '') {
            PromptFly_1.default.Show('请输入邮箱和密码');
            return;
        }
        if (!this.checkToggle.isChecked) {
            PromptFly_1.default.Show('请阅读并同意《用户协议》，《隐私政策》');
            return;
        }
        // Utils.openBundleView('pb/trunUI');
        xhrSupport_1.default.loginHtml(this.accountEidt.string, this.codeEidt.string, function (res) {
            res = JSON.parse(res);
            if (res.code == 1) {
                Utils_1.Utils.openBundleView('pb/trunUI');
                _this.closeView();
                UserInfo_1.default.userInfo = res.data.userInfo;
                cc.sys.localStorage.setItem("tcsToken", res.data.userInfo.token);
            }
            else {
                PromptFly_1.default.Show(res.msg);
            }
        }, function () { });
    };
    __decorate([
        property(cc.Node)
    ], loginNode.prototype, "btnClose", void 0);
    __decorate([
        property(cc.EditBox)
    ], loginNode.prototype, "accountEidt", void 0);
    __decorate([
        property(cc.EditBox)
    ], loginNode.prototype, "codeEidt", void 0);
    __decorate([
        property(cc.Toggle)
    ], loginNode.prototype, "checkToggle", void 0);
    __decorate([
        property(cc.Node)
    ], loginNode.prototype, "btnRegister", void 0);
    __decorate([
        property(cc.Node)
    ], loginNode.prototype, "btnRestPwd", void 0);
    __decorate([
        property(cc.Node)
    ], loginNode.prototype, "btnLogin", void 0);
    loginNode = __decorate([
        ccclass
    ], loginNode);
    return loginNode;
}(Lv_DialogView_1.default));
exports.default = loginNode;

cc._RF.pop();