"use strict";
cc._RF.push(module, 'a2170y1rmxPrrUycb8p/LAL', 'GameRoot');
// scripts/com/GameRoot.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var GameRoot = /** @class */ (function (_super) {
    __extends(GameRoot, _super);
    function GameRoot() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.openNode = null;
        _this.promptNode = null;
        _this.netTips = null;
        _this.lblTip = null;
        _this.touchNode = null;
        /** 服务器时间与本地时间同步 */
        _this.serverTime = 0;
        return _this;
        // update (dt) {}
    }
    GameRoot_1 = GameRoot;
    GameRoot.prototype.onLoad = function () {
        cc.game.addPersistRootNode(this.node);
    };
    GameRoot.prototype.start = function () {
        var _this = this;
        GameRoot_1.I = this;
        this.schedule(function () {
            if (_this.serverTime) {
                _this.serverTime += 1;
            }
        }, 1);
    };
    GameRoot.prototype.DisEnablePage = function () {
        this.touchNode.active = true;
    };
    GameRoot.prototype.EnablePage = function () {
        this.touchNode.active = false;
    };
    GameRoot.prototype.showNetTip = function (str) {
        this.netTips.active = true;
        this.lblTip.string = str;
    };
    GameRoot.prototype.closeNetTip = function () {
        this.netTips.active = false;
    };
    var GameRoot_1;
    GameRoot.I = null;
    __decorate([
        property(cc.Node)
    ], GameRoot.prototype, "openNode", void 0);
    __decorate([
        property(cc.Node)
    ], GameRoot.prototype, "promptNode", void 0);
    __decorate([
        property(cc.Node)
    ], GameRoot.prototype, "netTips", void 0);
    __decorate([
        property(cc.Label)
    ], GameRoot.prototype, "lblTip", void 0);
    __decorate([
        property(cc.Node)
    ], GameRoot.prototype, "touchNode", void 0);
    GameRoot = GameRoot_1 = __decorate([
        ccclass
    ], GameRoot);
    return GameRoot;
}(cc.Component));
exports.default = GameRoot;

cc._RF.pop();