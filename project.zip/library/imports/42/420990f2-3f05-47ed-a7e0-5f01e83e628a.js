"use strict";
cc._RF.push(module, '42099DyPwVH7afgXwHoPmKK', 'GameOver');
// scripts/GameOver.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var PromptFly_1 = require("./com/PromptFly");
var GButton_1 = require("./LGQ/GButton");
var Lv_DialogView_1 = require("./LGQ/Lv_DialogView");
var UserInfo_1 = require("./LGQ/UserInfo");
var Utils_1 = require("./LGQ/Utils");
var xhrSupport_1 = require("./LGQ/xhrSupport");
var AudioManager_1 = require("./LGQ/AudioManager");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var GameOver = /** @class */ (function (_super) {
    __extends(GameOver, _super);
    function GameOver() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.lblScore = null;
        _this.btnHome = null;
        _this.btnStart = null;
        return _this;
        // update (dt) {}
    }
    GameOver.prototype.onLoad = function () { };
    GameOver.prototype.start = function () {
        var _this = this;
        GButton_1.default.AddClick(this.btnHome, function () {
            _this.onClose();
            // cc.director.loadScene('start');
            Utils_1.Utils.openBundleView('pb/trunUI');
        }, this);
        // GButton.AddClick(this.btnStart, () => {
        //     this.onClose();
        //     cc.director.loadScene('game');
        // }, this);
        GButton_1.default.AddClick(this.btnStart, this.restartGame.bind(this), this);
    };
    GameOver.prototype.openUIData = function (data) {
        this.lblScore.string = data + "m";
        UserInfo_1.default.Game.doPause();
        AudioManager_1.default.playEffect("sound_lose");
    };
    GameOver.prototype.restartGame = function () {
        var _this = this;
        var call = function () {
            _this.onClose();
            Utils_1.Utils.removeAllView();
            xhrSupport_1.default.enterGameByScore(UserInfo_1.default.sceneTypeId, function (res) {
                res = JSON.parse(res);
                if (res.code == 1) {
                    // Utils.removeAllView();
                    cc.director.loadScene('game');
                    UserInfo_1.default.userInfo.score -= 10;
                    UserInfo_1.default.sceneId = res.data.id;
                }
                else {
                    PromptFly_1.default.Show(res.msg);
                }
            }, function () { });
        };
        Utils_1.Utils.openBundleView('pb/commonTipNode', [10, "是否消耗", "重玩游戏", call, "over"]);
    };
    __decorate([
        property(cc.Label)
    ], GameOver.prototype, "lblScore", void 0);
    __decorate([
        property(cc.Node)
    ], GameOver.prototype, "btnHome", void 0);
    __decorate([
        property(cc.Node)
    ], GameOver.prototype, "btnStart", void 0);
    GameOver = __decorate([
        ccclass
    ], GameOver);
    return GameOver;
}(Lv_DialogView_1.default));
exports.default = GameOver;

cc._RF.pop();