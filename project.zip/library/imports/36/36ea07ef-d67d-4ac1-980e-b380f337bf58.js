"use strict";
cc._RF.push(module, '36ea0fv1n1KwZgOs4DzN79Y', 'ResManager');
// scripts/LGQ/ResManager.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var ResManager = /** @class */ (function (_super) {
    __extends(ResManager, _super);
    function ResManager() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.bundle = null;
        return _this;
    }
    Object.defineProperty(ResManager, "I", {
        get: function () {
            if (!this._I) {
                this._I = new ResManager();
                this._I.init();
            }
            return this._I;
        },
        enumerable: false,
        configurable: true
    });
    ResManager.prototype.init = function () {
        this.bundle = cc.assetManager.getBundle("bundles");
    };
    //加载bundle下预制体
    ResManager.prototype.loadBundlePrefab = function (url, func) {
        if (!this.bundle) {
            this.bundle = cc.assetManager.getBundle("bundles");
        }
        this.bundle.load(url, cc.Prefab, function (err, assets) {
            if (err) {
                return;
            }
            func && func(assets);
        });
    };
    ResManager.prototype.preloadBundlePrefab = function (url, func, finishFunc) {
        if (!this.bundle) {
            this.bundle = cc.assetManager.getBundle("bundles");
        }
        this.bundle.preload(url, function (finish, total) {
            func && func(finish, total);
        }, finishFunc);
    };
    //加载resources下预制体
    ResManager.prototype.loadResPrefab = function (url, func) {
        cc.resources.load(url, cc.Prefab, function (err, assets) {
            if (err) {
                return;
            }
            func && func(assets);
        });
    };
    //加载bundle下图片
    ResManager.prototype.loadBundlePic = function (url, func) {
        if (!this.bundle) {
            this.bundle = cc.assetManager.getBundle("bundles");
        }
        this.bundle.load(url, cc.SpriteFrame, function (err, assets) {
            if (err) {
                return;
            }
            func && func(assets);
        });
    };
    //加载远程图片
    ResManager.prototype.loadRemotePic = function (url, func) {
        cc.assetManager.loadRemote(url, function (err, assets) {
            if (err) {
                return;
            }
            func && func(assets);
        });
    };
    ResManager.prototype.changeBundlePic = function (node, url, func) {
        this.loadBundlePic(url, function (spr) {
            if (!cc.isValid(node)) {
                return;
            }
            var sp = node.getComponent(cc.Sprite);
            if (!sp) {
                return;
            }
            sp.spriteFrame = spr;
            func && func();
        });
    };
    ResManager.prototype.changePic = function (node, url) {
        if (!url || url == "") {
            return;
        }
        this.loadRemotePic(url, function (tex) {
            if (!cc.isValid(node)) {
                return;
            }
            var sp = node.getComponent(cc.Sprite);
            if (!sp) {
                return;
            }
            sp.spriteFrame = new cc.SpriteFrame(tex);
        });
    };
    //加载bundle下骨骼动画
    ResManager.prototype.loadBundleSpine = function (url, func) {
        if (!this.bundle) {
            this.bundle = cc.assetManager.getBundle("bundles");
        }
        this.bundle.load(url, sp.SkeletonData, function (err, spData) {
            if (err) {
                return;
            }
            func && func(spData);
        });
    };
    ResManager.prototype.setGray = function (node, isGray) {
        if (cc.isValid(node)) {
            var arrSprite = node.getComponentsInChildren(cc.Sprite);
            for (var i = 0; i < arrSprite.length; i++) {
                var sp = arrSprite[i];
                if (sp) {
                    if (isGray) {
                        sp.setMaterial(0, cc.Material.getBuiltinMaterial("2d-gray-sprite"));
                    }
                    else {
                        sp.setMaterial(0, cc.Material.getBuiltinMaterial("2d-sprite"));
                    }
                }
            }
        }
    };
    ResManager._I = null;
    return ResManager;
}(cc.Component));
exports.default = ResManager;

cc._RF.pop();