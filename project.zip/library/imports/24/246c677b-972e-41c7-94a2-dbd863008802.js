"use strict";
cc._RF.push(module, '246c6d7ly5Bx5Si29hjAIgC', 'xhrSupport');
// scripts/LGQ/xhrSupport.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var httpUtil_1 = require("./httpUtil");
var xhrSupport = {
    httpUrl: "https://baozoutanchishe.test.xinzhiyukeji.cn/",
    // httpUrl: "http://192.168.0.90:10002/",
    loginHtml: function (account, password, successCb, failCb) {
        httpUtil_1.default.post(this.httpUrl + "api/Login/loginSn?server=1&account=" + account + "&password=" + password + "&type=emailLogin", {
            isNeedToken: false
        }, function (success) {
            successCb && successCb(success), (successCb = null);
        }, function (fail) {
            failCb && failCb(fail), (failCb = null);
        });
    },
    register: function (account, password, code, successCb, failCb) {
        httpUtil_1.default.post(this.httpUrl + "api/Login/register?server=1&account=" + account + "&captcha=" + code + "&password=" + password + "&type=email", {
            isNeedToken: false
        }, function (success) {
            successCb && successCb(success), (successCb = null);
        }, function (fail) {
            failCb && failCb(fail), (failCb = null);
        });
    },
    changePwd: function (account, password, captcha, successCb, failCb) {
        httpUtil_1.default.post(this.httpUrl + "api/Login/resetpwd?server=1&account=" + account + "&password=" + password + "&captcha=" + captcha, {
            isNeedToken: true
        }, function (success) {
            successCb && successCb(success), (successCb = null);
        }, function (fail) {
            failCb && failCb(fail), (failCb = null);
        });
    },
    getEmailCode: function (email, event, successCb, failCb) {
        httpUtil_1.default.post(this.httpUrl + "api/Ems/send?email=" + email + "&event=" + event + "&server=1", {
            isNeedToken: true
        }, function (success) {
            successCb && successCb(success), (successCb = null);
        }, function (fail) {
            failCb && failCb(fail), (failCb = null);
        });
    },
    getProtrol: function (type, successCb, failCb) {
        httpUtil_1.default.post(this.httpUrl + "api/Index/agreement?server=1&type=" + type, {
            isNeedToken: true
        }, function (success) {
            successCb && successCb(success), (successCb = null);
        }, function (fail) {
            failCb && failCb(fail), (failCb = null);
        });
    },
    getUserInfo: function (successCb, failCb) {
        httpUtil_1.default.post(this.httpUrl + "api/Login/refresh_user?server=1", {
            isNeedToken: true
        }, function (success) {
            successCb && successCb(success), (successCb = null);
        }, function (fail) {
            failCb && failCb(fail), (failCb = null);
        });
    },
    /**获取积分记录列表 */
    getScoreList: function (page, pagesize, successCb, failCb) {
        httpUtil_1.default.post(this.httpUrl + "api/Index/score_list?server=1&page=" + page + "&pagesize=" + pagesize, {
            isNeedToken: true
        }, function (success) {
            successCb && successCb(success), (successCb = null);
        }, function (fail) {
            failCb && failCb(fail), (failCb = null);
        });
    },
    getSceneList: function (page, pagesize, successCb, failCb) {
        httpUtil_1.default.post(this.httpUrl + "api/Index/scene_list?server=1&page=" + page + "&pagesize=" + pagesize, {
            isNeedToken: true
        }, function (success) {
            successCb && successCb(success), (successCb = null);
        }, function (fail) {
            failCb && failCb(fail), (failCb = null);
        });
    },
    enterGameByScore: function (sceneId, successCb, failCb) {
        httpUtil_1.default.post(this.httpUrl + "api/Index/pay_tickets?server=1&sceneId=" + sceneId, {
            isNeedToken: true
        }, function (success) {
            successCb && successCb(success), (successCb = null);
        }, function (fail) {
            failCb && failCb(fail), (failCb = null);
        });
    },
    getSkinList: function (page, pagesize, successCb, failCb) {
        httpUtil_1.default.post(this.httpUrl + "api/Index/skin_list?server=1&page=" + page + "&pagesize=" + pagesize, {
            isNeedToken: true
        }, function (success) {
            successCb && successCb(success), (successCb = null);
        }, function (fail) {
            failCb && failCb(fail), (failCb = null);
        });
    },
    buySkin: function (skinId, successCb, failCb) {
        httpUtil_1.default.post(this.httpUrl + "api/Index/buyskin?server=1&skinId=" + skinId, {
            isNeedToken: true
        }, function (success) {
            successCb && successCb(success), (successCb = null);
        }, function (fail) {
            failCb && failCb(fail), (failCb = null);
        });
    },
    useSkin: function (skinId, successCb, failCb) {
        httpUtil_1.default.post(this.httpUrl + "api/Index/choiceskin?server=1&skinId=" + skinId, {
            isNeedToken: true
        }, function (success) {
            successCb && successCb(success), (successCb = null);
        }, function (fail) {
            failCb && failCb(fail), (failCb = null);
        });
    },
    getUseingSkin: function (successCb, failCb) {
        httpUtil_1.default.post(this.httpUrl + "api/Login/usingskin?server=1", {
            isNeedToken: true
        }, function (success) {
            successCb && successCb(success), (successCb = null);
        }, function (fail) {
            failCb && failCb(fail), (failCb = null);
        });
    },
    getToolList: function (page, pagesize, successCb, failCb) {
        httpUtil_1.default.post(this.httpUrl + "api/Index/tools_list?server=1&page=" + page + "&pagesize=" + pagesize, {
            isNeedToken: true
        }, function (success) {
            successCb && successCb(success), (successCb = null);
        }, function (fail) {
            failCb && failCb(fail), (failCb = null);
        });
    },
    buyTool: function (toolsId, successCb, failCb) {
        httpUtil_1.default.post(this.httpUrl + "api/Index/buytools?server=1&toolsId=" + toolsId, {
            isNeedToken: true
        }, function (success) {
            successCb && successCb(success), (successCb = null);
        }, function (fail) {
            failCb && failCb(fail), (failCb = null);
        });
    },
    useTool: function (toolsId, successCb, failCb) {
        httpUtil_1.default.post(this.httpUrl + "api/Index/usetools?server=1&toolsId=" + toolsId, {
            isNeedToken: true
        }, function (success) {
            successCb && successCb(success), (successCb = null);
        }, function (fail) {
            failCb && failCb(fail), (failCb = null);
        });
    },
    endGame: function (id, game_score, is_normalover, successCb, failCb) {
        httpUtil_1.default.post(this.httpUrl + "api/Index/gameover?server=1&id=" + id + "&game_score=" + game_score + "&is_normalover=" + is_normalover, {
            isNeedToken: true
        }, function (success) {
            successCb && successCb(success), (successCb = null);
        }, function (fail) {
            failCb && failCb(fail), (failCb = null);
        });
    },
    getRechargeList: function (successCb, failCb) {
        httpUtil_1.default.post(this.httpUrl + "api/Index/coinlist?server=1&page=1&pagesize=999", {
            isNeedToken: true
        }, function (success) {
            successCb && successCb(success), (successCb = null);
        }, function (fail) {
            failCb && failCb(fail), (failCb = null);
        });
    },
    doRecharge: function (id, paytype, successCb, failCb) {
        httpUtil_1.default.post(this.httpUrl + "api/Index/recharge?server=1&product_id=" + id + "&pay_type=" + paytype, {
            isNeedToken: true
        }, function (success) {
            successCb && successCb(success), (successCb = null);
        }, function (fail) {
            failCb && failCb(fail), (failCb = null);
        });
    },
    //api/Index/applepay_averify
    RechargeCheck: function (receipt_data, order_sn, successCb, failCb) {
        httpUtil_1.default.post(this.httpUrl + "api/Index/applepay_averify&receipt_data=" + receipt_data + "&order_sn=" + order_sn, {
            isNeedToken: true
        }, function (success) {
            successCb && successCb(success), (successCb = null);
        }, function (fail) {
            failCb && failCb(fail), (failCb = null);
        });
    }
};
exports.default = xhrSupport;

cc._RF.pop();