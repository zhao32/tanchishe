"use strict";
cc._RF.push(module, '07795MSIwpKRI59TGa+B3tn', 'ModelPlayer');
// scripts/model/ModelPlayer.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var MsgCfg_1 = require("../com/MsgCfg");
var Utils_1 = require("../LGQ/Utils");
var ModelPlayer = /** @class */ (function () {
    function ModelPlayer() {
        this.isTeam = false;
        this.id = '';
        this.token = '';
        this.addr = '';
        this.at = "";
        this.name = '';
        this.avatar = '';
        this.Diamond = 0;
        this.Gold = 0;
        this.XNGold = 0;
        this.battleData = {};
        this.notice = [];
        this.friends = [];
        this.dogSite = [];
        this.home_level = 1;
        this.home_name = '';
        this.gameClose = 2;
        this.timer = null;
    }
    Object.defineProperty(ModelPlayer, "I", {
        get: function () {
            if (!this._I) {
                this._I = new ModelPlayer();
                this._I.init();
            }
            return this._I;
        },
        enumerable: false,
        configurable: true
    });
    ModelPlayer.prototype.init = function () {
        Utils_1.Utils.addInnerMsg(MsgCfg_1.InnerMsg.updatePlayerData, this, this.updatePlayerData);
    };
    ModelPlayer.prototype.updatePlayerData = function (data) {
        if (!data) {
            return;
        }
        //用户是否为新用户
        if (data.new || data.new <= 0) {
            this.isNewPlayer = data.new <= 0;
        }
        //用户token
        if (data.token) {
            this.token = data.token;
        }
        //用户手机号
        if (data.mobile) {
            this.mobile = data.mobile;
        }
        //用户openid
        if (data.openid) {
            this.openid = data.openid;
        }
        //用户ID
        if (data.id) {
            this.id = data.id;
        }
        //用户名字
        if (data.name) {
            this.name = data.name;
            Utils_1.Utils.sendInnerMsg(MsgCfg_1.InnerMsg.updatePlayerInfo);
        }
        //用户头像
        if (data.avatar) {
            this.avatar = data.avatar;
            Utils_1.Utils.sendInnerMsg(MsgCfg_1.InnerMsg.updatePlayerInfo);
        }
        //用户金币
        if (data.mp_commission >= 0) {
            this.Gold = data.mp_commission;
            Utils_1.Utils.sendInnerMsg(MsgCfg_1.InnerMsg.updateCurrent);
        }
        //用户钻石
        if (data.account >= 0) {
            this.Diamond = data.account;
            Utils_1.Utils.sendInnerMsg(MsgCfg_1.InnerMsg.updateCurrent);
        }
        //用户虚拟币
        if (data.XNGold >= 0) {
            this.XNGold = data.XNGold;
            Utils_1.Utils.sendInnerMsg(MsgCfg_1.InnerMsg.updateCurrent);
        }
        //好友列表
        if (data.haoyou) {
            this.friends = [];
            for (var i = 0; i < data.haoyou.length; i++) {
                var d = data.haoyou[i];
                this.friends.push(d);
            }
        }
        //狗场列表
        if (data.dogSite) {
            this.dogSite = [];
            for (var i = 0; i < data.dogSite.length; i++) {
                var d = data.dogSite[i];
                this.dogSite.push(d);
            }
        }
        //公会
        if (data.group_id) {
            this.userData.group_id = data.group_id;
        }
        //狗舍名字
        if (data.home_name) {
            this.home_name = data.home_name;
        }
        //狗舍等级
        if (data.home_level) {
            this.home_level = data.home_level;
            Utils_1.Utils.sendInnerMsg(MsgCfg_1.InnerMsg.upgradeHome);
        }
        // cc.log("数据更新", data, this.fighting_capacity);
    };
    ModelPlayer.prototype.updatePlayerNotice = function (data) {
        this.notice.push(data);
    };
    ModelPlayer.prototype.startHeartbeat = function () {
        if (!this.timer) {
            this.timer = setInterval(function () {
                Utils_1.Utils.getUserInfo();
            }, 3000);
        }
    };
    ModelPlayer.prototype.closeHeartbeat = function () {
        if (this.timer) {
            clearInterval(this.timer);
            this.timer = null;
        }
    };
    ModelPlayer._I = null;
    return ModelPlayer;
}());
exports.default = ModelPlayer;

cc._RF.pop();