"use strict";
cc._RF.push(module, '75b2d2d6VFJgpOUeKXcpCkt', 'skinNode');
// scripts/skinNode.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var PromptFly_1 = require("./com/PromptFly");
var EventManager_1 = require("./LGQ/EventManager");
var GButton_1 = require("./LGQ/GButton");
var Lv_DialogView_1 = require("./LGQ/Lv_DialogView");
var UserInfo_1 = require("./LGQ/UserInfo");
var Utils_1 = require("./LGQ/Utils");
var xhrSupport_1 = require("./LGQ/xhrSupport");
var skinItem_1 = require("./skinItem");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var NewClass = /** @class */ (function (_super) {
    __extends(NewClass, _super);
    function NewClass() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.btnClose = null;
        _this.btnRecharge = null;
        _this.btnLeft = null;
        _this.btnRight = null;
        _this.content = null;
        _this.itemPfb = null;
        _this.scrollView = null;
        _this.scoreLabel = null;
        return _this;
        // update (dt) {}
    }
    // LIFE-CYCLE CALLBACKS:
    // onLoad () {}
    NewClass.prototype.start = function () {
        var _this = this;
        GButton_1.default.AddClick(this.btnClose, function () { _this.closeView(); }, this);
        GButton_1.default.AddClick(this.btnLeft, this.onLeftHandler, this);
        GButton_1.default.AddClick(this.btnRight, this.onRightHandler, this);
        GButton_1.default.AddClick(this.btnRecharge, function () {
            Utils_1.Utils.openBundleView('pb/rechargeNode');
        }, this);
        this.scoreLabel.string = UserInfo_1.default.userInfo.score + '';
        xhrSupport_1.default.getSkinList(1, 100, function (res) {
            res = JSON.parse(res);
            if (res.code == 1) {
                _this.dataList = res.data.list;
                for (var i = 0; i < res.data.list.length; i++) {
                    var item = cc.instantiate(_this.itemPfb);
                    item.active = true;
                    item.y = 30;
                    _this.content.addChild(item);
                    item.getComponent(skinItem_1.default).init(res.data.list[i]);
                }
            }
            else {
                PromptFly_1.default.Show(res.msg);
            }
        }, function () { });
    };
    NewClass.prototype.onEnable = function () {
        EventManager_1.default.getInstance().registerListener(EventManager_1.default.CHANGE_SKIN, this, this.updateSkin.bind(this));
    };
    NewClass.prototype.updateSkin = function (id) {
        // for (let i = 0; i < this.content.children.length; i++) {
        //     if (this.content.children[i].getComponent(skinItem)._data.id == id) {
        //         this.content.children[i].getComponent(skinItem).onSelct();
        //     } else {
        //         this.content.children[i].getComponent(skinItem).unSelect();
        var _this = this;
        //     }
        // }
        xhrSupport_1.default.getSkinList(1, 100, function (res) {
            res = JSON.parse(res);
            if (res.code == 1) {
                _this.dataList = res.data.list;
                for (var i = 0; i < _this.content.children.length; i++) {
                    var item = _this.content.children[i];
                    item.getComponent(skinItem_1.default).init(res.data.list[i]);
                }
            }
            else {
                PromptFly_1.default.Show(res.msg);
            }
        }, function () { });
    };
    NewClass.prototype.onDisable = function () {
    };
    NewClass.prototype.onLeftHandler = function () {
        this.scrollView.scrollToLeft(0.5);
    };
    NewClass.prototype.onRightHandler = function () {
        this.scrollView.scrollToRight(0.5);
    };
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "btnClose", void 0);
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "btnRecharge", void 0);
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "btnLeft", void 0);
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "btnRight", void 0);
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "content", void 0);
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "itemPfb", void 0);
    __decorate([
        property(cc.ScrollView)
    ], NewClass.prototype, "scrollView", void 0);
    __decorate([
        property(cc.Label)
    ], NewClass.prototype, "scoreLabel", void 0);
    NewClass = __decorate([
        ccclass
    ], NewClass);
    return NewClass;
}(Lv_DialogView_1.default));
exports.default = NewClass;

cc._RF.pop();