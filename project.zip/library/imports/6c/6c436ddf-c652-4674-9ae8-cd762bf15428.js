"use strict";
cc._RF.push(module, '6c4363fxlJGdJrozXYr8VQo', 'MsgCfg');
// scripts/com/MsgCfg.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HttpType = exports.InnerMsg = void 0;
var InnerMsg;
(function (InnerMsg) {
    InnerMsg[InnerMsg["closeGame"] = 1] = "closeGame";
    InnerMsg[InnerMsg["restartGame"] = 2] = "restartGame";
    InnerMsg[InnerMsg["showGame"] = 3] = "showGame";
    InnerMsg[InnerMsg["gameResume"] = 4] = "gameResume";
    InnerMsg[InnerMsg["headPause"] = 5] = "headPause";
    InnerMsg[InnerMsg["updatePlayerData"] = 6] = "updatePlayerData";
    InnerMsg[InnerMsg["updatePlayerInfo"] = 7] = "updatePlayerInfo";
    InnerMsg[InnerMsg["updateCurrent"] = 8] = "updateCurrent";
    InnerMsg[InnerMsg["upgradeHome"] = 9] = "upgradeHome";
})(InnerMsg = exports.InnerMsg || (exports.InnerMsg = {}));
var HttpType;
(function (HttpType) {
    HttpType[HttpType["POST"] = 0] = "POST";
    HttpType[HttpType["GET"] = 1] = "GET";
})(HttpType = exports.HttpType || (exports.HttpType = {}));
var NetMsg = /** @class */ (function () {
    function NetMsg() {
    }
    /**登录 */
    NetMsg.login = { url: "api/Login/authLogin", type: HttpType.POST, isToken: false };
    /**绑定工号 */
    NetMsg.bindWorkLogin = { url: "api/Login/bindWorkLogin", type: HttpType.POST, isToken: false };
    /**用户信息 */
    NetMsg.getUserInfo = { url: "api/User/getUserInfo", type: HttpType.GET, isToken: true };
    /**修改用户信息 */
    NetMsg.setUserInfo = { url: "api/User/edit", type: HttpType.POST, isToken: true };
    /**提交得分 */
    NetMsg.addScore = { url: "api/user/addScore", type: HttpType.POST, isToken: true };
    /**排行榜 */
    NetMsg.getRank = { url: "api/user/scoreList", type: HttpType.GET, isToken: true };
    /**员工登录 */
    NetMsg.authWorkLogin = { url: "api/Login/authWorkLogin", type: HttpType.POST, isToken: false };
    return NetMsg;
}());
exports.default = NetMsg;

cc._RF.pop();