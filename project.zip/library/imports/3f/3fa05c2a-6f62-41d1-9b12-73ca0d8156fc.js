"use strict";
cc._RF.push(module, '3fa05wqb2JB0ZsSc8oNgVb8', 'EventManager');
// scripts/LGQ/EventManager.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var EventManager = /** @class */ (function () {
    function EventManager() {
        this.dic = {};
    }
    EventManager_1 = EventManager;
    EventManager.getInstance = function () {
        if (!this.instance) {
            this.instance = new EventManager_1();
        }
        return this.instance;
    };
    EventManager.prototype.registerListener = function (typeName, cc, action) {
        this.clearSingleRegister(typeName);
        if (!this.dic[typeName]) {
            this.dic[typeName] = [];
        }
        this.dic[typeName].push({ cc: cc, action: action });
    };
    EventManager.prototype.unRegisterListener = function (typeName, cc) {
        this.clearSingleRegister(typeName);
        if (!this.dic[typeName])
            return;
        this.dic[typeName].splice(this.dic[typeName].indexOf(cc), 1);
    };
    EventManager.prototype.clearSingleRegister = function (typeName) {
        if (this.dic[typeName]) {
            for (var i = this.dic[typeName].length - 1; i >= 0; i--) {
                if (!this.dic[typeName][i].cc.node) {
                    this.dic[typeName].splice(i, 1);
                }
            }
        }
    };
    EventManager.prototype.sendListener = function (typeName, obj) {
        this.clearSingleRegister(typeName);
        if (this.dic[typeName]) {
            for (var i = 0; i < this.dic[typeName].length; i++) {
                if (this.dic[typeName][i].cc.node) {
                    this.dic[typeName][i].action(this.dic[typeName][i].cc, obj);
                }
            }
        }
    };
    var EventManager_1;
    EventManager.CHANGE_SKIN = "change_skin";
    EventManager.UPDATE_SCORE = "UPDATE_SCORE";
    EventManager = EventManager_1 = __decorate([
        ccclass
    ], EventManager);
    return EventManager;
}());
exports.default = EventManager;

cc._RF.pop();