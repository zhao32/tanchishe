"use strict";
cc._RF.push(module, 'd634e0uFBVESIARw0bGV/M7', 'AudioManager');
// scripts/LGQ/AudioManager.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var AudioManager = /** @class */ (function (_super) {
    __extends(AudioManager, _super);
    function AudioManager() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    AudioManager.playEffect = function (eftName, volume) {
        var _this = this;
        if (volume === void 0) { volume = 1; }
        if (!this.isEffect) {
            return;
        }
        var cachedClip = this._audioRecords[eftName];
        if (cachedClip) {
            cc.audioEngine.play(cachedClip, false, volume);
            return;
        }
        cc.resources.load('music/' + eftName, cc.AudioClip, function (err, audioClip) {
            if (!err) {
                _this._audioRecords[eftName] = audioClip;
                cc.audioEngine.play(audioClip, false, volume);
            }
        });
    };
    AudioManager.playMusic = function (name, volume) {
        var _this = this;
        if (volume === void 0) { volume = 1; }
        var vol = volume;
        if (!this.isMusic) {
            vol = 0;
        }
        if (this.musicID) {
            cc.audioEngine.stop(this.musicID);
        }
        var cachedClip = this._audioRecords[name];
        if (cachedClip) {
            this.musicID = cc.audioEngine.play(cachedClip, true, vol);
            return;
        }
        cc.resources.load('music/' + name, cc.AudioClip, function (err, audioClip) {
            if (!err) {
                _this._audioRecords[name] = audioClip;
                _this.musicID = cc.audioEngine.play(audioClip, true, vol);
            }
        });
    };
    AudioManager.stopMusic = function () {
        cc.audioEngine.stop(this.musicID);
    };
    AudioManager.pauseMusic = function () {
        cc.audioEngine.setVolume(this.musicID, 0);
    };
    AudioManager.resumeMusic = function () {
        cc.audioEngine.setVolume(this.musicID, 1);
    };
    AudioManager.updateMusic = function (data) {
        if (data) {
            if (this.isMusic != data.isMusic) {
                if (data.isMusic) {
                    this.resumeMusic();
                }
                else {
                    this.pauseMusic();
                }
                this.isMusic = data.isMusic;
            }
            this.isEffect = data.isEffect;
        }
    };
    AudioManager.isEffect = true;
    AudioManager.isMusic = true;
    AudioManager.musicID = null;
    AudioManager._audioRecords = {};
    AudioManager = __decorate([
        ccclass
    ], AudioManager);
    return AudioManager;
}(cc.Component));
exports.default = AudioManager;

cc._RF.pop();