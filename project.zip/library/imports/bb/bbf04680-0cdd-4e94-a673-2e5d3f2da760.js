"use strict";
cc._RF.push(module, 'bbf04aADN1OlKZzLl0/Ladg', 'food');
// scripts/food.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var food = /** @class */ (function (_super) {
    __extends(food, _super);
    function food() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    // LIFE-CYCLE CALLBACKS:
    // onLoad () {}
    // start () {
    // }
    food.prototype.onLoad = function () {
        // this.node.color = this.randomColor();
        this.node.setPosition(this.randomPos());
    };
    food.prototype.randomColor = function () {
        // get random color
        var red = Math.round(Math.random() * 255);
        var green = Math.round(Math.random() * 255);
        var blue = Math.round(Math.random() * 255);
        return new cc.Color(red, green, blue);
    };
    food.prototype.randomPos = function () {
        var width = this.node.parent.width;
        var height = this.node.parent.height;
        var x = Math.round(Math.random() * width) - width / 2;
        var y = Math.round(Math.random() * height) - height / 2;
        if (x <= -(width / 2 + this.node.width * 2)) {
            x = -(width / 2 + this.node.width * 2);
        }
        if (y <= -(height / 2 + this.node.height * 2)) {
            y = -(height / 2 + this.node.height * 2);
        }
        if (x >= (width / 2 - this.node.width * 2)) {
            x = width / 2 - this.node.width * 2;
        }
        if (y > (height / 2 - this.node.height * 2)) {
            y = height / 2 - this.node.height * 2;
        }
        return cc.v2(x, y);
    };
    food = __decorate([
        ccclass
    ], food);
    return food;
}(cc.Component));
exports.default = food;

cc._RF.pop();