"use strict";
cc._RF.push(module, 'f1d5ckAMDZDk4akMq+5mD5H', 'trunUI');
// scripts/trunUI.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var PromptFly_1 = require("./com/PromptFly");
var EventManager_1 = require("./LGQ/EventManager");
var GButton_1 = require("./LGQ/GButton");
var Lv_DialogView_1 = require("./LGQ/Lv_DialogView");
var UserInfo_1 = require("./LGQ/UserInfo");
var Utils_1 = require("./LGQ/Utils");
var xhrSupport_1 = require("./LGQ/xhrSupport");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var NewClass = /** @class */ (function (_super) {
    __extends(NewClass, _super);
    function NewClass() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.btnSet = null;
        _this.btnRecharge = null;
        _this.btnSkin = null;
        _this.btnRecord = null;
        _this.btnStart = null;
        _this.scoreLabel = null;
        _this.sceneDataList = [];
        return _this;
        // update (dt) {}
    }
    // LIFE-CYCLE CALLBACKS:
    // onLoad () {}
    NewClass.prototype.onEnable = function () {
        EventManager_1.default.getInstance().registerListener(EventManager_1.default.UPDATE_SCORE, this, this.updateScore.bind(this));
    };
    NewClass.prototype.onDisable = function () {
        EventManager_1.default.getInstance().unRegisterListener(EventManager_1.default.UPDATE_SCORE, this);
    };
    NewClass.prototype.updateScore = function () {
        this.scoreLabel.string = UserInfo_1.default.userInfo.score.toString();
    };
    NewClass.prototype.start = function () {
        var _this = this;
        GButton_1.default.AddClick(this.btnSet, function () {
            Utils_1.Utils.openBundleView('pb/setNode', "trun");
        }, this);
        GButton_1.default.AddClick(this.btnRecharge, function () {
            Utils_1.Utils.openBundleView('pb/rechargeNode');
        }, this);
        GButton_1.default.AddClick(this.btnSkin, function () {
            Utils_1.Utils.openBundleView('pb/skinNode');
        }, this);
        GButton_1.default.AddClick(this.btnRecord, function () {
            Utils_1.Utils.openBundleView('pb/recordNode');
        }, this);
        GButton_1.default.AddClick(this.btnStart, function () {
            var call = function () {
                xhrSupport_1.default.enterGameByScore(_this.sceneDataList[UserInfo_1.default.sceneIdx].id, function (res) {
                    res = JSON.parse(res);
                    if (res.code == 1) {
                        Utils_1.Utils.removeAllView();
                        cc.director.loadScene('game');
                        UserInfo_1.default.userInfo.score -= 10;
                        UserInfo_1.default.sceneId = res.data.id;
                        UserInfo_1.default.sceneTypeId = _this.sceneDataList[UserInfo_1.default.sceneIdx].id;
                    }
                    else {
                        PromptFly_1.default.Show(res.msg);
                    }
                }, function () { });
            };
            Utils_1.Utils.openBundleView('pb/commonTipNode', [10, "是否消耗", "并进入游戏", call]);
        }, this);
        this.scoreLabel.string = UserInfo_1.default.userInfo.score.toString();
        xhrSupport_1.default.getSceneList(1, 100, function (res) {
            res = JSON.parse(res);
            if (res.code == 1) {
                _this.sceneDataList = res.data.list;
            }
            else {
                PromptFly_1.default.Show(res.msg);
            }
        }, function () { });
    };
    NewClass.prototype.onToggleScene = function (event, customEventData) {
        UserInfo_1.default.sceneIdx = parseInt(customEventData);
    };
    NewClass.prototype.onToggleDifficulty = function (event, customEventData) {
        UserInfo_1.default.difficultyValue = parseInt(customEventData);
    };
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "btnSet", void 0);
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "btnRecharge", void 0);
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "btnSkin", void 0);
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "btnRecord", void 0);
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "btnStart", void 0);
    __decorate([
        property(cc.Label)
    ], NewClass.prototype, "scoreLabel", void 0);
    NewClass = __decorate([
        ccclass
    ], NewClass);
    return NewClass;
}(Lv_DialogView_1.default));
exports.default = NewClass;

cc._RF.pop();