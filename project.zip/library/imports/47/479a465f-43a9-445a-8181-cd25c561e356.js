"use strict";
cc._RF.push(module, '479a4ZfQ6lEWoGBzSXFYeNW', 'httpUtil');
// scripts/LGQ/httpUtil.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var httpUtil = {
    request: function (method, url, data, success, fail, header, responseType) {
        if (header === undefined)
            header = {};
        // if (responseType == undefined) {
        //     responseType = cc.sys.isNative ? "json" : "";
        // }
        var xhr = new XMLHttpRequest();
        xhr.open(method, url, true);
        if (data.isNeedToken) {
            // xhr.setRequestHeader('authorization', "Bearer " + cc.sys.localStorage.getItem("UserToken"));
            // xhr.setRequestHeader('UserID', cc.sys.localStorage.getItem("UserID"));
            xhr.setRequestHeader('bausertoken', cc.sys.localStorage.getItem("tcsToken"));
        }
        xhr.setRequestHeader('Content-type', 'application/json;charset=utf-8');
        delete data.isNeedToken;
        data = JSON.stringify(data);
        for (var Key in header) {
            xhr.setRequestHeader(Key, header[Key]);
        }
        xhr.responseType = responseType;
        xhr.timeout = 15000; // 超时时间，单位是毫秒
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4) {
                if (xhr.status >= 200 && xhr.status < 300) {
                    console.log(JSON.stringify(xhr.response));
                    if (success) {
                        success(xhr.response);
                    }
                }
                else {
                    if (fail) {
                        fail(xhr);
                        fail = null;
                    }
                }
            }
        };
        xhr.onerror = function () {
            console.log("http request onerror");
            fail && fail(xhr);
            fail = null;
        };
        xhr.ontimeout = function (e) {
            console.log("http request timeout");
            fail && fail(xhr);
            fail = null;
        };
        console.log("http request methord:" + method + ",body:" + data);
        xhr.send(data);
    },
    get: function (url, data, success, fail, header, responseType) {
        console.log(this);
        return httpUtil.request('GET', url, data, success, fail, header, responseType);
    },
    post: function (url, data, success, fail, header, responseType) {
        console.log(this);
        return httpUtil.request('POST', url, data, success, fail, header, responseType);
    },
    put: function (url, data, success, fail, header, responseType) {
        console.log(this);
        return httpUtil.request('PUT', url, data, success, fail, header, responseType);
    },
};
exports.default = httpUtil;

cc._RF.pop();