"use strict";
cc._RF.push(module, 'bef04KGvi5ACL/XoxMs/CLv', 'Utils');
// scripts/LGQ/Utils.ts

"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Utils = void 0;
var GameRoot_1 = require("../com/GameRoot");
// import { GameNet } from "./GameNetManager";
var Lv_DialogView_1 = require("./Lv_DialogView");
// import { CallbackObject, IRequestProtocol } from "./NetInterface";
var ResManager_1 = require("./ResManager");
var NumType = {
    1: "一",
    2: "二",
    3: "三",
    4: "四",
    5: "五",
    6: "六",
    7: "七",
    8: "八",
    9: "九",
    10: "十",
};
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Utils = /** @class */ (function () {
    function Utils() {
    }
    //打开bundle预制体页面
    Utils.openBundleView = function (url, openData) {
        var _this = this;
        var urlArr = url.split("/");
        var name = urlArr[urlArr.length - 1];
        if (this.openViewArr.indexOf(name) >= 0) {
            cc.log("当前页面已打开");
            return;
        }
        this.openViewArr.push(name);
        ResManager_1.default.I.loadBundlePrefab(url, function (pb) {
            if (pb) {
                var view = cc.instantiate(pb);
                GameRoot_1.default.I.openNode.addChild(view);
                var dialogView = view.getComponent(Lv_DialogView_1.default);
                if (openData && dialogView) {
                    dialogView.openUIData(openData);
                }
            }
            else {
                var index = _this.openViewArr.indexOf(name);
                if (index >= 0) {
                    _this.openViewArr.splice(index, 1);
                }
            }
        });
    };
    //关闭页面
    Utils.removeView = function (name) {
        for (var i = 0; i < GameRoot_1.default.I.openNode.childrenCount; i++) {
            var node = GameRoot_1.default.I.openNode.children[i];
            if (cc.isValid(node) && node.name == name) {
                node.removeFromParent();
                node.destroy();
                var index = this.openViewArr.indexOf(name);
                if (index >= 0) {
                    this.openViewArr.splice(index, 1);
                }
            }
        }
    };
    //关闭所有页面
    Utils.removeAllView = function () {
        GameRoot_1.default.I.openNode.removeAllChildren();
        this.openViewArr = [];
    };
    //  事件
    Utils.sendInnerMsg = function (type, data) {
        this.initEvent();
        this.eventTarget.emit(type, data);
    };
    Utils.addInnerMsg = function (type, target, func) {
        this.initEvent();
        this.eventTarget.on(type, func, target);
    };
    Utils.removeInnerMsg = function (type, target, func) {
        this.initEvent();
        this.eventTarget.off(type, func, target);
    };
    Utils.initEvent = function () {
        if (!this.eventTarget) {
            this.eventTarget = new cc.EventTarget();
        }
    };
    // static sendNetSocketMsg(method: string, data: any, rspObject: CallbackObject, showTips: boolean = true, force: boolean = false) {
    //     // cc.log("数据请求参数", method, data);
    //     // data["curtime"] = GameRoot.I.getServerTime();
    //     let protocol: IRequestProtocol = {
    //         action: method,
    //         data: data,
    //         // isCompress: false
    //     }
    //     // return this.request(protocol, rspObject, showTips, force);
    //     return GameNet.game!.request(protocol, rspObject, showTips, force);
    // }
    // static addNetSocketMsg(type, target, func) {
    //     GameNet.game?.addResponeHandler(type, func, target);
    // }
    // static removeNetSocketMsg(type, target?, func?) {
    //     GameNet.game?.removeResponeHandler(type, func, target);
    // }
    Utils.setConvertNum = function (num) {
        if (num >= 100) {
            return num;
        }
        var numStr = "";
        var num1 = Math.floor(num / 10);
        var num2 = Math.floor(num % 10);
        if (num1 > 0) {
            if (num1 == 1) {
                numStr += "十";
            }
            else {
                numStr += (NumType[num1] + "十");
            }
        }
        if (num2 > 0) {
            numStr += NumType[num2];
        }
        return numStr;
    };
    Utils.getTimeStr = function (time, isHour) {
        if (isHour === void 0) { isHour = false; }
        var seperator1 = "-";
        var seperator2 = ":";
        var date = new Date(time);
        var year = date.getFullYear();
        var mon = date.getMonth() + 1;
        var day = date.getDate();
        var h = date.getHours();
        var m = date.getMinutes();
        var s = date.getSeconds();
        if (mon < 10 && mon > 0) {
            mon = "0" + mon;
        }
        if (day < 10 && day > 0) {
            day = "0" + day;
        }
        if (h < 10 && h >= 0) {
            h = "0" + h;
        }
        if (m < 10 && m >= 0) {
            m = "0" + m;
        }
        if (s < 10 && s >= 0) {
            s = "0" + s;
        }
        var str = year + seperator1 + mon + seperator1 + day;
        if (isHour) {
            str = str + " " + h + seperator2 + m + seperator2 + s;
        }
        return str;
    };
    Utils.DisEnablePage = function (time) {
        var _this = this;
        if (time === void 0) { time = 0.5; }
        GameRoot_1.default.I.DisEnablePage();
        this.pageTimeOut = setTimeout(function () {
            _this.EnablePage();
        }, time * 1000);
    };
    Utils.EnablePage = function () {
        GameRoot_1.default.I.EnablePage();
        if (this.pageTimeOut) {
            clearTimeout(this.pageTimeOut);
            this.pageTimeOut = null;
        }
    };
    Utils.getDistance = function (p1, p2) {
        var dx = p2.x - p1.x;
        var dy = p2.y - p1.y;
        return Math.sqrt(dx * dx + dy * dy);
    };
    Utils.getUserInfo = function () {
        // Utils.sendNetMsg(NetMsg.getUserInfo, null, (msg) => {
        //     Utils.sendInnerMsg(InnerMsg.updatePlayerData, msg.data.user_info);
        // });
    };
    Utils.isLogin = false;
    Utils.loginUrl = "https://moonlake.site/";
    Utils.payUrl = "https://moonlake.site/pay.html";
    Utils.shareUrl = "https://moonlake.site/#";
    Utils.curNandu = 1;
    Utils.zhangjieId = 1;
    Utils.levelId = 1;
    Utils.eventTarget = null;
    Utils.openViewArr = [];
    Utils = __decorate([
        ccclass
    ], Utils);
    return Utils;
}());
exports.Utils = Utils;

cc._RF.pop();