"use strict";
cc._RF.push(module, 'bef26KiyVBPp4HgbRcgaUkW', 'ScrollViewListItem');
// scripts/LGQ/ScrollViewListItem.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var SelectedType = {
    NONE: 0,
    TOGGLE: 1,
    SWITCH: 2,
};
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property, menu = _a.menu;
var ScrollViewListItem = /** @class */ (function (_super) {
    __extends(ScrollViewListItem, _super);
    function ScrollViewListItem() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.selectedMode = SelectedType.NONE;
        _this.selectedFlag = null;
        _this.selectedSpriteFrame = null;
        _this.adaptiveSize = false;
        _this._selected = false;
        _this._btnCom = null;
        return _this;
        // update (dt) {}
    }
    Object.defineProperty(ScrollViewListItem.prototype, "selected", {
        get: function () {
            return this._selected;
        },
        set: function (val) {
            this._selected = val;
            if (!this.selectedFlag)
                return;
            switch (this.selectedMode) {
                case SelectedType.TOGGLE:
                    this.selectedFlag.active = val;
                    break;
                case SelectedType.SWITCH:
                    // this.selectedFlag.node.active = true;
                    this.selectedFlag.spriteFrame = val ? this.selectedSpriteFrame : this._unselectedSpriteFrame;
                    break;
            }
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(ScrollViewListItem.prototype, "btnCom", {
        get: function () {
            if (!this._btnCom)
                this._btnCom = this.node.getComponent(cc.Button);
            return this._btnCom;
        },
        enumerable: false,
        configurable: true
    });
    ScrollViewListItem.prototype.onLoad = function () {
        //强行把文字组件转换给title...方便使用
        // if (this.title) {
        //     let com = this.title.getComponent(cc.Label);
        //     if (!com)
        //         com = this.title.getComponent(cc.RichText);
        //     this.title = com;
        // }
        // //没有按钮组件的话，selectedFlag无效
        // if (!this.btnCom)
        //     this.selectedMode == SelectedType.NONE;
        //有选择模式时，保存相应的东西
        if (this.selectedMode == SelectedType.SWITCH) {
            var com = this.selectedFlag.getComponent(cc.Sprite);
            // if (!com)
            //     cc.error('SelectedMode为"SWITCH"时，selectedFlag必须要有cc.Sprite组件！');
            this.selectedFlag = com;
            this._unselectedSpriteFrame = com.spriteFrame;
        }
        this.onloadOnce();
    };
    ScrollViewListItem.prototype.onDestroy = function () {
        this.node.off(cc.Node.EventType.SIZE_CHANGED, this._onSizeChange, this);
        this.onDestroyOnce();
    };
    ScrollViewListItem.prototype.onloadOnce = function () {
    };
    ScrollViewListItem.prototype.onDestroyOnce = function () {
    };
    ScrollViewListItem.prototype._registerEvent = function () {
        if (!this.eventReg) {
            if (this.btnCom && this._list.selectedMode > 0) {
                this.btnCom.clickEvents.unshift(this.createEvt(this, 'onClickThis'));
            }
            if (this.adaptiveSize) {
                this.node.on(cc.Node.EventType.SIZE_CHANGED, this._onSizeChange, this);
            }
            this.eventReg = true;
        }
        this.setstartInfo();
    };
    ScrollViewListItem.prototype.setstartInfo = function () { };
    ScrollViewListItem.prototype._onSizeChange = function () {
        this._list._onItemAdaptive(this.node);
    };
    /**
         * 创建事件
         * @param {cc.Component} component 组件脚本
         * @param {string} handlerName 触发函数名称
         * @param {cc.Node} node 组件所在node（不传的情况下取component.node）
         * @returns cc.Component.EventHandler
         */
    ScrollViewListItem.prototype.createEvt = function (component, handlerName, node) {
        if (!component.isValid)
            return; //有些异步加载的，节点以及销毁了。
        component.comName = component.comName || component.name.match(/\<(.*?)\>/g).pop().replace(/\<|>/g, '');
        var evt = new cc.Component.EventHandler();
        evt.target = node || component.node;
        evt.component = component.comName;
        evt.handler = handlerName;
        return evt;
    };
    ScrollViewListItem.prototype.showAni = function (aniType, callFunc, del) {
        var _this = this;
        var acts;
        switch (aniType) {
            case 0: //向上消失
                acts = [
                    cc.scaleTo(.2, .7),
                    cc.moveBy(.3, 0, this.node.height * 2),
                ];
                break;
            case 1: //向右消失
                acts = [
                    cc.scaleTo(.2, .7),
                    cc.moveBy(.3, this.node.width * 2, 0),
                ];
                break;
            case 2: //向下消失
                acts = [
                    cc.scaleTo(.2, .7),
                    cc.moveBy(.3, 0, this.node.height * -2),
                ];
                break;
            case 3: //向左消失
                acts = [
                    cc.scaleTo(.2, .7),
                    cc.moveBy(.3, this.node.width * -2, 0),
                ];
                break;
            default: //默认：缩小消失
                acts = [
                    cc.scaleTo(.3, .1),
                ];
                break;
        }
        if (callFunc || del) {
            acts.push(cc.callFunc(function () {
                if (del) {
                    _this._list._delSingleItem(_this.node);
                    for (var n = _this._list.displayData.length - 1; n >= 0; n--) {
                        var node = _this.node;
                        if (_this._list.displayData[n].listId == node._listId) {
                            _this._list.displayData.splice(n, 1);
                            break;
                        }
                    }
                }
                callFunc();
            }));
        }
        this.node.runAction(cc.sequence(acts));
    };
    ScrollViewListItem.prototype.onClickThis = function () {
        // if (this._list.selectedMode == 1)
        var node = this.node;
        this._list.selectedId = node._listId;
    };
    __decorate([
        property({
            tooltip: "选择模式: 0: 普通, 1: 单一（单个Node显示/隐藏）, 2: 切换(单个Sprite切换SpriteFrame)",
        })
    ], ScrollViewListItem.prototype, "selectedMode", void 0);
    __decorate([
        property({
            type: cc.Node,
            tooltip: "选择Flag",
            visible: function () {
                var bool = this.selectedMode > 0;
                if (!bool)
                    this.selectedFlag = null;
                return bool;
            },
        })
    ], ScrollViewListItem.prototype, "selectedFlag", void 0);
    __decorate([
        property({
            type: cc.SpriteFrame,
            tooltip: "选择图片",
            visible: function () {
                var bool = this.selectedMode == SelectedType.SWITCH;
                if (!bool)
                    this.selectedSpriteFrame = null;
                return bool;
            },
        })
    ], ScrollViewListItem.prototype, "selectedSpriteFrame", void 0);
    __decorate([
        property({
            tooltip: "自适应尺寸（宽或高）",
        })
    ], ScrollViewListItem.prototype, "adaptiveSize", void 0);
    ScrollViewListItem = __decorate([
        ccclass,
        menu('自定义组件/ScrollViewListItem')
    ], ScrollViewListItem);
    return ScrollViewListItem;
}(cc.Component));
exports.default = ScrollViewListItem;

cc._RF.pop();