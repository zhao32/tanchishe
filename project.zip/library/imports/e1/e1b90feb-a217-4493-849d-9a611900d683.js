"use strict";
cc._RF.push(module, 'e1b90/rohdEk4SdmmEZANaD', 'head');
// scripts/head.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var MsgCfg_1 = require("./com/MsgCfg");
var Game_1 = require("./Game");
var ResManager_1 = require("./LGQ/ResManager");
var UserInfo_1 = require("./LGQ/UserInfo");
var Utils_1 = require("./LGQ/Utils");
var monster_1 = require("./monster");
var AudioManager_1 = require("./LGQ/AudioManager");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var head = /** @class */ (function (_super) {
    __extends(head, _super);
    function head() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.ndWei = null;
        _this.ndFood = null;
        _this.ndBG = null;
        _this.bodyPrefab = null;
        _this.headSp = null;
        _this.headSpFrames = [];
        _this.bodySpFrames = [];
        // @property([cc.Prefab])
        // foodPrefabS: Array<cc.Prefab> = new Array<cc.Prefab>();
        // @property
        // text: string = 'hello';
        _this.bodyNum = 2;
        _this.foodNum = 30;
        _this.monsterNum = 5;
        // the length of each section(section between body prefabs)
        _this.sectionLen = 45;
        _this.weiLen = 40;
        _this.headLen = 40;
        _this.snakeArray = [];
        _this.pointsArray = [];
        _this.weiPossArray = [];
        _this.time = 9;
        _this.speed = 4;
        _this.disSpeed = 0.2;
        _this.dir = null;
        _this.headPointsNum = 0;
        _this.foodType = 20;
        _this.isFirst = false;
        _this.isYuanbao = false;
        _this.monsterArray = [];
        _this.score = 0;
        _this.isGameOVer = false;
        _this.isStartColl = false;
        return _this;
    }
    head.prototype.onLoad = function () {
        // set head's color
        this.isFirst = true;
        this.headPointsNum = 0;
        this.pointsArray = [];
        this.snakeArray = [];
        this.snakeArray.push(this.node);
        this.snakeArray.push(this.ndWei);
        this.snakeArray[this.snakeArray.length - 1].curIndex = 0;
        this.headSp.spriteFrame = this.headSpFrames[UserInfo_1.default.userInfo.skinId - 1];
        // this.speed = this.sectionLen / this.time;
        for (var i = 1; i <= this.bodyNum; i++) {
            this.getNewBody();
        }
        // this.node.setPosition(this.randomPos());
        // this.rotateHead(this.node.position);
        // produce new food
        for (var i = 0; i < this.foodNum; i++) {
            this.getNewFood();
        }
        var monsterNumList = [10, 20, 30];
        for (var i = 0; i < monsterNumList[UserInfo_1.default.difficultyValue]; i++) {
            this.getNewMonster();
        }
    };
    head.prototype.onEnable = function () {
        Utils_1.Utils.addInnerMsg(MsgCfg_1.InnerMsg.headPause, this, this.gamePause);
    };
    head.prototype.onDestroy = function () {
        // touch event
        Utils_1.Utils.removeInnerMsg(MsgCfg_1.InnerMsg.headPause, this, this.gamePause);
    };
    head.prototype.randomColor = function () {
        // get random color
        var red = Math.round(Math.random() * 255);
        var green = Math.round(Math.random() * 255);
        var blue = Math.round(Math.random() * 255);
        return new cc.Color(red, green, blue);
    };
    head.prototype.randomPos = function () {
        // get random position
        var width = this.node.parent.width;
        var height = this.node.parent.height;
        var x = Math.round(Math.random() * width) - width / 2;
        var y = Math.round(Math.random() * height) - height / 2;
        return cc.v2(x, y);
    };
    head.prototype.addSpeed = function () {
        this.speed += 2;
        this.recordPointsAll();
    };
    head.prototype.resumeSpeed = function () {
        this.speed -= 2;
        this.recordPointsAll();
    };
    head.prototype.getNewFood = function () {
        var _this = this;
        var rand = Math.random() * 100;
        var type = 0;
        // if (rand < 50) {
        //     if (Math.random() * 100 < 50) {
        //         type = 1
        //     }
        // } else {
        //     type = Math.floor(Math.random() * (this.foodType - 2)) + 2;
        // }
        ResManager_1.default.I.loadBundlePrefab("pb/item/food" + type, function (pb) {
            var newFood = cc.instantiate(pb);
            _this.ndFood.addChild(newFood);
        });
    };
    head.prototype.getNewMonster = function () {
        var _this = this;
        // let type = Math.floor(Math.random() * 2);
        // type = 1;
        var type = "";
        ResManager_1.default.I.loadBundlePrefab("pb/item/monster" + type, function (pb) {
            var newMonster = cc.instantiate(pb);
            _this.ndFood.addChild(newMonster);
            _this.monsterArray.push(newMonster);
        });
    };
    head.prototype.getNewBody = function () {
        // initialize body or get longer after eating food
        // let newBody = cc.instantiate(this.bodyPrefab);
        // let item = newBody.getComponent("body");
        // item.curIndex = 0;
        var newBody = cc.instantiate(this.bodyPrefab);
        newBody.getComponent(cc.Sprite).spriteFrame = this.bodySpFrames[UserInfo_1.default.userInfo.skinId - 1];
        if (this.snakeArray.length > this.bodyNum) {
            newBody.curIndex = this.snakeArray[this.snakeArray.length - 1].curIndex;
        }
        else {
            newBody.curIndex = 0;
        }
        // set new body's position
        if (this.snakeArray.length == 2) {
            var dir = this.node.position.normalize();
            dir = this.node.position.sub(this.ndWei.position).normalize();
            newBody.setPosition(this.node.position.sub(dir.mul(this.sectionLen)));
            newBody.angle = this.node.angle;
            this.ndWei.setPosition(newBody.position.sub(dir.mul(this.sectionLen)));
        }
        else {
            var lastBody = this.snakeArray[this.snakeArray.length - 2];
            var lastBOBody = this.snakeArray[this.snakeArray.length - 3];
            var dir = lastBOBody.position.sub(lastBody.position).normalize();
            newBody.setPosition(lastBody.position.sub(dir.mul(this.sectionLen)));
            newBody.angle = lastBody.angle;
            // this.ndWei.setPosition(this.ndWei.position.sub(dir.mul(this.sectionLen)));
            this.ndWei.setPosition(newBody.position.sub(dir.mul(this.sectionLen)));
        }
        // // new body's color should be same as that of head
        // newBody.color = this.node.color;
        // add to canvas and snakeArray
        this.node.parent.addChild(newBody);
        this.snakeArray.splice(this.snakeArray.length - 1, 0, newBody);
        // this.snakeArray.push(newBody);
        this.recordPoints();
        this.changeZIndex();
    };
    head.prototype.rotateHead = function (headPos) {
        // change head's direction
        var angle = cc.v2(1, 0).signAngle(headPos) * 180 / Math.PI;
        // this.node.angle = angle-90;
        this.node.angle = angle;
    };
    // moveSnake() {
    //     // move snake
    //     let dis = this.dir.mul(this.speed);
    //     this.node.setPosition(this.node.position.add(dis));
    //     this.pointsArray.push(this.node.position);
    // }
    head.prototype.moveSnake = function () {
        // move snake
        var dis = this.dir.mul(this.speed);
        this.node.setPosition(this.node.position.add(dis));
        this.pointsArray.push(this.node.position);
        this.weiPossArray.push(this.node.position);
        // plus one every time when head moves
        this.headPointsNum += 1;
        // console.log(this.snakeArray.length);
        for (var i = 1; i < this.snakeArray.length; i++) {
            var num = Math.floor((this.pointsArray.length - this.headPointsNum) / (this.snakeArray.length - 1) * (this.snakeArray.length - 1 - i));
            // console.log(num);
            // console.log(this.snakeArray[i].curIndex);
            if (i == this.snakeArray.length - 1) {
                var pos = this.weiPossArray[num + this.snakeArray[i].curIndex].sub(this.snakeArray[i].position);
                if (pos != cc.Vec2.ZERO) {
                    var angle = cc.v2(1, 0).signAngle(pos) * 180 / Math.PI;
                    this.snakeArray[i].angle = angle;
                }
                this.snakeArray[i].setPosition(this.weiPossArray[num + this.snakeArray[i].curIndex]);
                this.snakeArray[i].curIndex += 1;
            }
            else {
                var pos = this.pointsArray[num + this.snakeArray[i].curIndex].sub(this.snakeArray[i].position);
                if (pos != cc.Vec2.ZERO) {
                    var angle = cc.v2(1, 0).signAngle(pos) * 180 / Math.PI;
                    this.snakeArray[i].angle = angle;
                }
                this.snakeArray[i].setPosition(this.pointsArray[num + this.snakeArray[i].curIndex]);
                this.snakeArray[i].curIndex += 1;
            }
        }
    };
    head.prototype.recordPointsAll = function () {
        this.pointsArray = [];
        this.headPointsNum = 0;
        for (var i = 1; i < this.snakeArray.length - 1; i++) {
            this.snakeArray[i].curIndex = 0;
            var len = 0;
            var index = 0;
            var maxLen = this.sectionLen;
            while (len < maxLen) {
                len += this.speed;
                var lastBody = this.snakeArray[i];
                var lastBOBody = this.snakeArray[i - 1];
                var dir = lastBOBody.position.sub(lastBody.position).normalize();
                var pos = lastBody.position.add(dir.mul(len));
                this.pointsArray.splice(index, 0, pos);
                index += 1;
            }
            ;
        }
        this.recordPointsWei();
    };
    head.prototype.recordPoints = function () {
        // record points between bodies (head is a special body)
        var len = 0;
        var index = 0;
        var maxLen = this.sectionLen;
        while (len < maxLen) {
            len += this.speed;
            var lastBody = this.snakeArray[this.snakeArray.length - 2];
            var lastBOBody = this.snakeArray[this.snakeArray.length - 3];
            var dir = lastBOBody.position.sub(lastBody.position).normalize();
            var pos = lastBody.position.add(dir.mul(len));
            this.pointsArray.splice(index, 0, pos);
            index += 1;
        }
        ;
        this.recordPointsWei();
    };
    head.prototype.recordPointsWei = function () {
        // record points between bodies (head is a special body)
        this.weiPossArray = [];
        var len = 0;
        var index = 0;
        var maxLen = 0; //this.sectionLen/4;
        for (var i = 0; i < this.pointsArray.length; i++) {
            var pos = this.pointsArray[i];
            this.weiPossArray.push(pos);
        }
        this.snakeArray[this.snakeArray.length - 1].curIndex = 0;
        while (len < maxLen) {
            len += this.speed;
            var lastBody = this.snakeArray[this.snakeArray.length - 1];
            var lastBOBody = this.snakeArray[this.snakeArray.length - 2];
            var dir = lastBOBody.position.sub(lastBody.position).normalize();
            var pos = lastBody.position.add(dir.mul(len));
            this.weiPossArray.splice(index, 0, pos);
            index += 1;
        }
        ;
    };
    head.prototype.changeZIndex = function () {
        for (var i = 0; i < this.snakeArray.length; i++) {
            this.snakeArray[i].zIndex = cc.macro.MAX_ZINDEX - i;
        }
    };
    head.prototype.onCollisionEnter = function (other, self) {
        // remove current food
        if (Game_1.default.I.isPause) {
            return;
        }
        var group = other.node.group;
        switch (group) {
            case "food":
                this.isStartColl = true;
                other.node.removeFromParent();
                AudioManager_1.default.playEffect("bonus");
                // produce new food
                this.getNewFood();
                // generate new body
                this.getNewBody();
                this.score += 10;
                // if (this.score % 20 == 0) {
                //     this.getNewMonster();
                // }
                Game_1.default.I.addScore(10);
                this.speed += this.disSpeed;
                this.recordPointsAll();
                break;
            case "food1":
                this.isStartColl = true;
                this.isYuanbao = false;
                other.node.removeFromParent();
                AudioManager_1.default.playEffect("bonus");
                // produce new food
                this.getNewFood();
                // generate new body
                this.getNewBody();
                this.score += 20;
                // if (this.score % 20 == 0) {
                //     this.getNewMonster();
                // }
                Game_1.default.I.addScore(20);
                this.speed = this.speed + this.disSpeed * 2;
                this.recordPointsAll();
                break;
            case "body":
                if (this.isStartColl && UserInfo_1.default.invincible == false) {
                    Game_1.default.I.isPause = true;
                    this.gamePause();
                    console.log("gameover 碰撞身体");
                    Game_1.default.I.setGameOver();
                }
                break;
            case "wall":
                if (UserInfo_1.default.invincible == false) {
                    Game_1.default.I.isPause = true;
                    this.gamePause();
                    console.log("gameover 碰撞沙滩");
                    Game_1.default.I.setGameOver();
                }
                break;
            case "monster":
                if (UserInfo_1.default.invincible == false) {
                    Game_1.default.I.isPause = true;
                    this.gamePause();
                    console.log("gameover 碰撞金鱼");
                    Game_1.default.I.setGameOver();
                }
                break;
            default:
                break;
        }
    };
    head.prototype.update = function (dt) {
        if (Game_1.default.I.isPause) {
            return;
        }
        if (this.dir) {
            // change head's direction
            this.rotateHead(this.dir);
            // move snake
            this.moveSnake();
        }
    };
    head.prototype.gamePause = function () {
        for (var i = 0; i < this.monsterArray.length; i++) {
            var node = this.monsterArray[i];
            if (cc.isValid(node)) {
                node.getComponent(monster_1.default).gamePause();
            }
        }
    };
    head.prototype.gameResume = function () {
        for (var i = 0; i < this.monsterArray.length; i++) {
            var node = this.monsterArray[i];
            if (cc.isValid(node)) {
                node.getComponent(monster_1.default).gameResume();
            }
        }
    };
    __decorate([
        property(cc.Node)
    ], head.prototype, "ndWei", void 0);
    __decorate([
        property(cc.Node)
    ], head.prototype, "ndFood", void 0);
    __decorate([
        property(cc.Node)
    ], head.prototype, "ndBG", void 0);
    __decorate([
        property(cc.Prefab)
    ], head.prototype, "bodyPrefab", void 0);
    __decorate([
        property(cc.Sprite)
    ], head.prototype, "headSp", void 0);
    __decorate([
        property(cc.SpriteFrame)
    ], head.prototype, "headSpFrames", void 0);
    __decorate([
        property(cc.SpriteFrame)
    ], head.prototype, "bodySpFrames", void 0);
    head = __decorate([
        ccclass
    ], head);
    return head;
}(cc.Component));
exports.default = head;

cc._RF.pop();