"use strict";
cc._RF.push(module, '81164k1a99Bc7VuWBvqB5HL', 'JoyStick');
// scripts/JoyStick.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var JoyStick = /** @class */ (function (_super) {
    __extends(JoyStick, _super);
    function JoyStick() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.player = null;
        // @property
        // text: string = 'hello';
        _this.maxSpeed = 10;
        return _this;
    }
    JoyStick.prototype.start = function () {
        // init logic
        // this.label.string = this.text;
    };
    JoyStick.prototype.onLoad = function () {
        // hide FPS info
        cc.debug.setDisplayStats(false);
        this.joyStickBtn = this.node.children[2].children[0];
        console.log(this.joyStickBtn);
        // this.joyStickBtn = this.node.getComponent("da").getComponent("xiao"); 
        // touch event
        this.node.on('touchstart', this.onTouchStart, this);
        this.node.on('touchmove', this.onTouchMove, this);
        this.node.on('touchend', this.onTouchEnd, this);
    };
    JoyStick.prototype.onDestroy = function () {
        // touch event
        this.node.off('touchstart', this.onTouchStart, this);
        this.node.off('touchmove', this.onTouchMove, this);
        this.node.off('touchend', this.onTouchEnd, this);
        this.node.off('touchcancel', this.onTouchCancel, this);
    };
    JoyStick.prototype.onTouchStart = function (event) {
        // when touch starts, set joyStickBtn's position 
        var pos = this.joyStickBtn.convertToNodeSpaceAR(event.getLocation());
        this.joyStickBtn.setPosition(pos);
    };
    JoyStick.prototype.onTouchMove = function (event) {
        // constantly change joyStickBtn's position
        // let posDelta = event.getDelta();
        // this.joyStickBtn.setPosition(this.joyStickBtn.position.add(posDelta));
        // this.dir = this.joyStickBtn.position.normalize();
        var posDelta = event.getDelta();
        this.joyStickBtn.setPosition(this.joyStickBtn.position.add(posDelta));
        // get direction
        var dir = this.joyStickBtn.position.normalize();
        this.player.getComponent("head").dir = dir;
    };
    JoyStick.prototype.onTouchEnd = function (event) {
        // reset
        this.joyStickBtn.setPosition(cc.v2(0, 0));
    };
    JoyStick.prototype.onTouchCancel = function (event) {
        // reset
        this.joyStickBtn.setPosition(cc.v2(0, 0));
    };
    JoyStick.prototype.update = function (dt) {
        // get ratio
        var len = this.joyStickBtn.position.mag();
        var maxLen = 200 / 2;
        var ratio = len / maxLen;
        // restrict joyStickBtn inside the joyStickPanel
        if (ratio > 1) {
            this.joyStickBtn.setPosition(this.joyStickBtn.position.div(ratio));
        }
        // let dis = this.dir.mul(this.maxSpeed * ratio);
        // this.player.setPosition(this.player.position.add(dis))
        if (this.player.x > this.player.parent.width / 2)
            this.player.x = this.player.parent.width / 2;
        else if (this.player.x < -this.player.parent.width / 2)
            this.player.x = -this.player.parent.width / 2;
        if (this.player.y > this.player.parent.height / 2)
            this.player.y = this.player.parent.height / 2;
        else if (this.player.y < -this.player.parent.height / 2)
            this.player.y = -this.player.parent.height / 2;
    };
    __decorate([
        property(cc.Node)
    ], JoyStick.prototype, "player", void 0);
    JoyStick = __decorate([
        ccclass
    ], JoyStick);
    return JoyStick;
}(cc.Component));
exports.default = JoyStick;

cc._RF.pop();