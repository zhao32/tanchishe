"use strict";
cc._RF.push(module, '1e64687xkdPqboLXqZj88kM', 'Lv_DialogView');
// scripts/LGQ/Lv_DialogView.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
// import CurrentNode from "../CurrentNode";
var GButton_1 = require("./GButton");
var ResManager_1 = require("./ResManager");
var Utils_1 = require("./Utils");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Lv_DialogView = /** @class */ (function (_super) {
    __extends(Lv_DialogView, _super);
    function Lv_DialogView() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Lv_DialogView.prototype.onPrefabShow = function (data) {
        var _this = this;
        if (data === void 0) { data = { isClose: true }; }
        ResManager_1.default.I.loadResPrefab('pb/DialogView', function (pb) {
            if (cc.isValid(_this.node)) {
                var node = cc.instantiate(pb);
                _this.node.addChild(node);
                node.zIndex = -1;
                if (data.isClose) {
                    GButton_1.default.AddClick(node, _this.onClose, _this, null, null, null, 0, false);
                }
            }
        });
    };
    // currenBtnType: 0:全显示按钮，1：显示充值，2：显示兑换，3：不显示
    Lv_DialogView.prototype.onCurrentShow = function (data) {
        // ResManager.I.loadBundlePrefab('pb/TopNode', (pb) => {
        //     if (cc.isValid(this.node)) {
        //         let item: cc.Node = cc.instantiate(pb);
        //         this.node.addChild(item);
        //         item.zIndex = 10000;
        if (data === void 0) { data = {
            hideClose: false,
            currenBtnType: 0
        }; }
        //         let node = item.getChildByName("panelCurrent");
        //         ResManager.I.loadBundlePrefab('pb/CurrentNode', (pb) => {
        //             if (cc.isValid(node)) {
        //                 let currentNode: cc.Node = cc.instantiate(pb);
        //                 node.addChild(currentNode);
        //                 currentNode.getComponent(CurrentNode).setData(data);
        //             }
        //         })
        //         //返回按钮
        //         let btn_close = item.getChildByName('close');
        //         btn_close.active = !data.hideClose;
        //         GButton.AddClick(btn_close, this.onClose, this);
        //     }
        // });
    };
    Lv_DialogView.prototype.openUIData = function (data) {
    };
    Lv_DialogView.prototype.onClose = function () {
        this.closeView();
    };
    Lv_DialogView.prototype.closeView = function () {
        if (this.node)
            Utils_1.Utils.removeView(this.node.name);
    };
    Lv_DialogView = __decorate([
        ccclass
    ], Lv_DialogView);
    return Lv_DialogView;
}(cc.Component));
exports.default = Lv_DialogView;

cc._RF.pop();