"use strict";
cc._RF.push(module, 'e4204xyrHRJUpVhEi9Egx6A', 'GButton');
// scripts/LGQ/GButton.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var AudioManager_1 = require("./AudioManager");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var GButton = /** @class */ (function (_super) {
    __extends(GButton, _super);
    function GButton() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    GButton.AddClick = function (node, endFunc, target, startFunc, moveFunc, cancelFunc, type, isScale) {
        if (type === void 0) { type = 1; }
        if (isScale === void 0) { isScale = true; }
        if (!cc.isValid(node)) {
            return;
        }
        var scale = node.scale;
        node.on(cc.Node.EventType.TOUCH_START, function (e) {
            if (!cc.isValid(node)) {
                return;
            }
            if (isScale) {
                node.scale = scale * 1.05;
            }
            if (type == 1) {
                //播放点击按钮音效
                AudioManager_1.default.playEffect("click");
            }
            startFunc && startFunc.call(target, e);
        }, target);
        node.on(cc.Node.EventType.TOUCH_MOVE, function (e) {
            if (!cc.isValid(node)) {
                return;
            }
            moveFunc && moveFunc.call(target, e);
        }, target);
        node.on(cc.Node.EventType.TOUCH_END, function (e) {
            if (!cc.isValid(node)) {
                return;
            }
            if (isScale) {
                node.scale = scale;
            }
            endFunc && endFunc.call(target, e);
        }, target);
        node.on(cc.Node.EventType.TOUCH_CANCEL, function (e) {
            if (!cc.isValid(node)) {
                return;
            }
            if (isScale) {
                node.scale = scale;
            }
            cancelFunc && cancelFunc.call(target, e);
        }, target);
    };
    GButton.RemoveAndAddClick = function (node, endFunc, target, startFunc, moveFunc, cancelFunc, type, isScale) {
        if (type === void 0) { type = 1; }
        if (isScale === void 0) { isScale = true; }
        if (!cc.isValid(node)) {
            return;
        }
        this.removeClick(node);
        this.AddClick(node, endFunc, target, startFunc, moveFunc, cancelFunc, type, isScale);
    };
    GButton.removeClick = function (node) {
        if (!cc.isValid(node)) {
            return;
        }
        node.off(cc.Node.EventType.TOUCH_START);
        node.off(cc.Node.EventType.TOUCH_MOVE);
        node.off(cc.Node.EventType.TOUCH_END);
        node.off(cc.Node.EventType.TOUCH_CANCEL);
    };
    GButton = __decorate([
        ccclass
    ], GButton);
    return GButton;
}(cc.Component));
exports.default = GButton;

cc._RF.pop();