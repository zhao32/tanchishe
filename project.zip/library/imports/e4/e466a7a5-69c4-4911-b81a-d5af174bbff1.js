"use strict";
cc._RF.push(module, 'e466aelacRJEbga1a8XS7/x', 'Start');
// scripts/Start.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var AudioManager_1 = require("./LGQ/AudioManager");
var GButton_1 = require("./LGQ/GButton");
var UserInfo_1 = require("./LGQ/UserInfo");
var Utils_1 = require("./LGQ/Utils");
var xhrSupport_1 = require("./LGQ/xhrSupport");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Start = /** @class */ (function (_super) {
    __extends(Start, _super);
    function Start() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.btnLogin = null;
        // @property(cc.Node)
        // ndLogin: cc.Node = null;
        // @property(cc.Node)
        // ndMain: cc.Node = null;
        _this.loginBG = null;
        // @property(cc.Node)
        // ndGH: cc.Node = null;
        // @property(cc.EditBox)
        // editBox: cc.EditBox = null;
        // @property(cc.Node)
        // btnGH: cc.Node = null;
        // @property(cc.Node)
        // btnMusic: cc.Node = null;
        // @property(cc.Node)
        // ndKai: cc.Node = null;
        // @property(cc.Node)
        // ndGuan: cc.Node = null;
        _this.pro = null;
        _this.proIcon = null;
        _this.loadFinished = false;
        _this.isStart = false;
        _this.bgUrl = "https://tanchishedw.xinzhiyukeji.cn/uploads/home_background.png";
        return _this;
        // onClickMusic() {
        //     let musicData = UserInfo.getItem(UserCfg.MusicData, false);
        //     if (!musicData) {
        //         let data = {
        //             isMusic: true,
        //             isEffect: true
        //         }
        //         musicData = data;
        //         UserInfo.setItem(UserCfg.MusicData, musicData, false);
        //     }
        //     musicData.isMusic = !musicData.isMusic;
        //     musicData.isEffect = !musicData.isEffect;
        //     if (musicData.isMusic) {//播放音乐
        //         AudioManager.resumeMusic();
        //     }
        //     else {//停止音乐
        //         AudioManager.pauseMusic();
        //     }
        //     AudioManager.updateMusic(musicData);
        //     this.ndKai.active = musicData.isMusic;
        //     this.ndGuan.active = !musicData.isMusic;
        //     UserInfo.setItem(UserCfg.MusicData, musicData, false);
        // }
        // update (dt) {}
    }
    Start.prototype.update = function (dt) {
        var _this = this;
        if (this.pro.progress < 1) {
            if (Math.random() * 1 > 0.3)
                this.pro.progress += 0.01;
            this.proIcon.x = this.pro.totalLength * this.pro.progress;
        }
        else {
            if (this.loadFinished == false) {
                this.loadFinished = true;
                xhrSupport_1.default.getUserInfo(function (res) {
                    res = JSON.parse(res);
                    if (res.code == 1) {
                        _this.node.getChildByName('loginNode').active = false;
                        Utils_1.Utils.openBundleView('pb/trunUI');
                        UserInfo_1.default.userInfo = res.data.userInfo;
                    }
                    else {
                        _this.btnLogin.active = true;
                        _this.pro.node.parent.active = false;
                    }
                }, function (fail) {
                    _this.btnLogin.active = true;
                    _this.pro.node.parent.active = false;
                });
            }
        }
    };
    Start.prototype.onLoad = function () {
        // ResManager.I.changePic(this.loginBG, this.bgUrl);
    };
    Start.prototype.start = function () {
        this.loadFinished = false;
        this.pro.node.parent.active = true;
        this.pro.progress = 0;
        this.btnLogin.active = false;
        GButton_1.default.AddClick(this.btnLogin, function () {
            Utils_1.Utils.openBundleView('pb/loginNode');
        }, this);
        this.node.getChildByName('loginNode').active = true;
        this.loadBundle();
        cc.director.preloadScene('game');
        AudioManager_1.default.playMusic("gameBGM");
        // this.ndLogin.active = false;
        // let isCodeBtn = false;
        // let isWxLogin = false;
        // let data: any = {};
        // if (!Utils.isLogin) {
        //     this.ndLogin.active = true;
        //     this.loadBundle();
        //     cc.director.preloadScene('game');
        //     // if (cc.sys.platform == cc.sys.WECHAT_GAME) {
        //     //     SdkUtils.login((code) => {
        //     //         SdkUtils.getUserInfo((res) => {
        //     //             isWxLogin = true;
        //     //             let name = res.nickName;
        //     //             let avatarUrl = res.avatarUrl;
        //     //             // console.log("数据11111111", code, res);
        //     //             //登录接口
        //     //             data = {
        //     //                 code: code,
        //     //                 avatarUrl: avatarUrl,
        //     //                 nickName: name
        //     //             }
        //     //             if (isCodeBtn) {
        //     //                 Utils.sendNetMsg(NetMsg.login, data, (res) => {
        //     //                     if (res && res.code == 1) {
        //     //                         let _data = res.data;
        //     //                         ModelPlayer.I.token = _data.token;
        //     //                         let nData = _data.user;
        //     //                         ModelPlayer.I.avatar = nData.avatarUrl;
        //     //                         ModelPlayer.I.name = nData.nickName;
        //     //                         ModelPlayer.I.openid = nData.openid;
        //     //                         ModelPlayer.I.unionid = nData.unionid;
        //     //                         ModelPlayer.I.id = nData.id;
        //     //                         ModelPlayer.I.gameClose = nData.game_close;
        //     //                         if (_data.isBindWork == 1) {    //1,需要绑定;0,不需要绑定
        //     //                             this.btnLogin.active = false;
        //     //                             this.ndGH.active = true;
        //     //                         } else {
        //     //                             Utils.isLogin = true;
        //     //                             this.showMain();
        //     //                         }
        //     //                     }
        //     //                 });
        //     //             }
        //     //         }, () => {
        //     //             isCodeBtn = true;
        //     //         });
        //     //     });
        //     //     GButton.AddClick(this.btnLogin, () => {
        //     //         if (!isCodeBtn && isWxLogin) {
        //     //             Utils.sendNetMsg(NetMsg.login, data, (res) => {
        //     //                 if (res && res.code == 1) {
        //     //                     let _data = res.data;
        //     //                     ModelPlayer.I.token = _data.token;
        //     //                     let nData = _data.user;
        //     //                     ModelPlayer.I.avatar = nData.avatarUrl;
        //     //                     ModelPlayer.I.name = nData.nickName;
        //     //                     ModelPlayer.I.openid = nData.openid;
        //     //                     ModelPlayer.I.unionid = nData.unionid;
        //     //                     ModelPlayer.I.id = nData.id;
        //     //                     ModelPlayer.I.gameClose = nData.game_close;
        //     //                     if (_data.isBindWork == 1) {    //1,需要绑定;0,不需要绑定
        //     //                         this.btnLogin.active = false;
        //     //                         this.ndGH.active = true;
        //     //                     } else {
        //     //                         Utils.isLogin = true;
        //     //                         this.showMain();
        //     //                     }
        //     //                 }
        //     //             });
        //     //         }
        //     //     }, this);
        //     // } else {
        //     //     isCodeBtn = false;
        //     //     isWxLogin = true;
        //     //     this.btnLogin.active = false;
        //     //     this.ndGH.active = true;
        //     //     // let userData = UserInfo.getItem(UserCfg.Token, false);
        //     //     // // console.log("数据11111111111", userData);
        //     //     // if (!userData || !userData.gonghao || userData.gonghao == '') {
        //     //     //     this.ndGH.active = true;
        //     //     // } else {
        //     //     //     Utils.isLogin = true;
        //     //     //     this.ndGH.active = false;
        //     //     //     // ModelPlayer.I.token = userData.token;
        //     //     //     // ModelPlayer.I.id = userData.id;
        //     //     //     let data = {
        //     //     //         work_number: userData.gonghao,
        //     //     //     };
        //     //     //     Utils.sendNetMsg(NetMsg.authWorkLogin, data, (res) => {
        //     //     //         if (res && res.code == 1) {
        //     //     //             let _data = res.data;
        //     //     //             ModelPlayer.I.token = _data.token;
        //     //     //             let nData = _data.user;
        //     //     //             ModelPlayer.I.avatar = nData.avatar;
        //     //     //             ModelPlayer.I.name = nData.name;
        //     //     //             ModelPlayer.I.id = nData.id;
        //     //     //             let da = {
        //     //     //                 token: _data.token,
        //     //     //                 id: nData.id,
        //     //     //                 gonghao: userData.gonghao,
        //     //     //             }
        //     //     //             UserInfo.setItem(UserCfg.Token, da, false)
        //     //     //             Utils.isLogin = true;
        //     //     //             this.showMain();
        //     //     //         }
        //     //     //     })
        //     //     //     this.showMain();
        //     //     // }
        //     // }
        // } else {
        //     // this.showMain();
        // }
        // GButton.AddClick(this.btnGH, () => {
        //     //验证工号
        //     // cc.log("数据111111111111");
        //     let str = this.editBox.string;
        //     if (!str || str == '') {
        //         PromptFly.Show("请输入工号");
        //         return;
        //     }
        //     if (cc.sys.platform == cc.sys.WECHAT_GAME) {
        //         let data = {
        //             work_number: str,
        //             openid: ModelPlayer.I.openid,
        //             unionid: ModelPlayer.I.unionid,
        //             avatarUrl: ModelPlayer.I.avatar,
        //             nickName: ModelPlayer.I.name,
        //         };
        //         Utils.sendNetMsg(NetMsg.bindWorkLogin, data, (res) => {
        //             if (res && res.code == 1) {
        //                 let _data = res.data;
        //                 ModelPlayer.I.token = _data.token;
        //                 let nData = _data.user;
        //                 ModelPlayer.I.avatar = nData.avatar;
        //                 ModelPlayer.I.name = nData.name;
        //                 ModelPlayer.I.id = nData.id;
        //                 Utils.isLogin = true;
        //                 this.showMain();
        //             }
        //         })
        //     } else {
        //         let data = {
        //             work_number: str,
        //         };
        //         Utils.sendNetMsg(NetMsg.authWorkLogin, data, (res) => {
        //             if (res && res.code == 1) {
        //                 let _data = res.data;
        //                 ModelPlayer.I.token = _data.token;
        //                 let nData = _data.user;
        //                 ModelPlayer.I.avatar = nData.avatar;
        //                 ModelPlayer.I.name = nData.name;
        //                 ModelPlayer.I.id = nData.id;
        //                 let da = {
        //                     token: _data.token,
        //                     id: nData.id,
        //                     gonghao: str,
        //                 }
        //                 UserInfo.setItem(UserCfg.Token, da, false)
        //                 Utils.isLogin = true;
        //                 this.showMain();
        //             }
        //         })
        //     }
        // }, this);
        // GButton.AddClick(this.btnMusic, this.onClickMusic, this);
    };
    // showMain() {
    //     let musicData = UserInfo.getItem(UserCfg.MusicData, false);
    //     if (!musicData) {
    //         let data = {
    //             isMusic: true,
    //             isEffect: true
    //         }
    //         musicData = data;
    //         UserInfo.setItem(UserCfg.MusicData, musicData, false);
    //     }
    //     AudioManager.updateMusic(musicData);
    //     this.ndKai.active = musicData.isMusic;
    //     this.ndGuan.active = !musicData.isMusic;
    //     AudioManager.playMusic("gameBGM");
    //     this.ndLogin.active = false;
    //     this.ndMain.active = true;
    // }
    Start.prototype.loadBundle = function () {
        var _this = this;
        var self = this;
        cc.assetManager.loadBundle("bundles", function () {
        }, function () {
            cc.log("分包加载成功");
            var bundle = cc.assetManager.getBundle("bundles");
            if (bundle) {
                bundle.preloadDir("pb", function (completedCount, totalCount) {
                    // var pro = (completedCount / totalCount) * 0.5;
                    // pro = pro <= 0.5 ? pro : 0.5;
                    // self.setProBar(pro);
                }, function () {
                    cc.log("分包预加载资源成功");
                    _this.isStart = true;
                    // cc.director.preloadScene("gameScene", (completedCount, totalCount, item) => {
                    //     var pro = (completedCount / totalCount) * 0.5;
                    //     pro = pro <= 0.5 ? pro : 0.5;
                    //     self.setProBar(pro + 0.5);
                    // }, () => {
                    //     cc.director.loadScene("gameScene");
                    // })
                });
            }
        });
    };
    __decorate([
        property(cc.Node)
    ], Start.prototype, "btnLogin", void 0);
    __decorate([
        property(cc.Node)
    ], Start.prototype, "loginBG", void 0);
    __decorate([
        property(cc.ProgressBar)
    ], Start.prototype, "pro", void 0);
    __decorate([
        property(cc.Node)
    ], Start.prototype, "proIcon", void 0);
    Start = __decorate([
        ccclass
    ], Start);
    return Start;
}(cc.Component));
exports.default = Start;

cc._RF.pop();