"use strict";
cc._RF.push(module, '762e1w2LmVN+rS7jQv0GiJj', 'UserInfo');
// scripts/LGQ/UserInfo.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserCfg = void 0;
var GameData = /** @class */ (function () {
    function GameData() {
    }
    /**场景类型id */
    GameData.sceneTypeId = 0;
    /**进入场景时的id 有唯一性 */
    GameData.sceneId = 0;
    GameData.sceneIdx = 0;
    GameData.difficultyValue = 0;
    /**免伤状态 */
    GameData.invincible = false;
    /**加速 */
    GameData.accelerate = false;
    return GameData;
}());
exports.default = GameData;
var UserCfg;
(function (UserCfg) {
    UserCfg[UserCfg["Yinsi"] = 1] = "Yinsi";
    UserCfg[UserCfg["Mobile"] = 2] = "Mobile";
    UserCfg[UserCfg["MusicData"] = 3] = "MusicData";
    UserCfg[UserCfg["Yuyan"] = 4] = "Yuyan";
    UserCfg[UserCfg["IsGuide"] = 5] = "IsGuide";
    UserCfg[UserCfg["GodId"] = 6] = "GodId";
    UserCfg[UserCfg["Token"] = 7] = "Token";
})(UserCfg = exports.UserCfg || (exports.UserCfg = {}));

cc._RF.pop();