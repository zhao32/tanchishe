"use strict";
cc._RF.push(module, '02174cBdb5K35NKzWYjJAWU', 'setNode');
// scripts/setNode.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var MsgCfg_1 = require("./com/MsgCfg");
var AudioManager_1 = require("./LGQ/AudioManager");
var GButton_1 = require("./LGQ/GButton");
var Lv_DialogView_1 = require("./LGQ/Lv_DialogView");
var UserInfo_1 = require("./LGQ/UserInfo");
var Utils_1 = require("./LGQ/Utils");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var NewClass = /** @class */ (function (_super) {
    __extends(NewClass, _super);
    function NewClass() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.btnClose = null;
        _this.btnSound = null;
        _this.btnMusic = null;
        _this.btnLoginOut = null;
        _this.btnGameOut = null;
        _this.btnResetPwd = null;
        _this.chatSp = [];
        // LIFE-CYCLE CALLBACKS:
        _this._from = "";
        return _this;
        // update (dt) {}
    }
    // onLoad () {}
    NewClass.prototype.start = function () {
        GButton_1.default.AddClick(this.btnClose, this.onClose, this);
        GButton_1.default.AddClick(this.btnSound, this.onBtnSound, this);
        GButton_1.default.AddClick(this.btnMusic, this.onBtnMusic, this);
        GButton_1.default.AddClick(this.btnLoginOut, this.onLoginOut, this);
        GButton_1.default.AddClick(this.btnGameOut, this.onOutGame, this);
        GButton_1.default.AddClick(this.btnResetPwd, function () {
            Utils_1.Utils.openBundleView("pb/getPwdNode", "修改");
        }, this);
        this.btnSound.getComponent(cc.Sprite).spriteFrame = this.chatSp[AudioManager_1.default.isEffect ? 0 : 1];
        this.btnMusic.getComponent(cc.Sprite).spriteFrame = this.chatSp[AudioManager_1.default.isMusic ? 0 : 1];
        this.isQuit = false;
    };
    NewClass.prototype.onBtnSound = function () {
        AudioManager_1.default.isEffect = !AudioManager_1.default.isEffect;
        this.btnSound.getComponent(cc.Sprite).spriteFrame = this.chatSp[AudioManager_1.default.isEffect ? 0 : 1];
    };
    NewClass.prototype.onBtnMusic = function () {
        AudioManager_1.default.isMusic = !AudioManager_1.default.isMusic;
        this.btnMusic.getComponent(cc.Sprite).spriteFrame = this.chatSp[AudioManager_1.default.isMusic ? 0 : 1];
        if (AudioManager_1.default.isMusic) { //播放音乐
            AudioManager_1.default.resumeMusic();
        }
        else { //停止音乐
            AudioManager_1.default.pauseMusic();
        }
    };
    NewClass.prototype.openUIData = function (from) {
        if (from === void 0) { from = "trun"; }
        this._from = from;
        if (from == "trun") {
            this.btnLoginOut.active = true;
            this.btnGameOut.active = false;
        }
        else {
            this.btnLoginOut.active = false;
            this.btnGameOut.active = true;
            UserInfo_1.default.Game.doPause();
        }
    };
    NewClass.prototype.onLoginOut = function () {
        localStorage.clear();
        Utils_1.Utils.removeAllView();
        cc.director.loadScene('start');
    };
    NewClass.prototype.onOutGame = function () {
        var _this = this;
        var call = function () {
            _this.isQuit = true;
            _this.closeView();
            UserInfo_1.default.Game.quitBySet();
        };
        Utils_1.Utils.openBundleView('pb/commonTipNode', [10, "现在退出将损失", "是否退出？", call, "set"]);
    };
    NewClass.prototype.onClose = function () {
        this.closeView();
        if (this._from != "trun" && !this.isQuit) {
            Utils_1.Utils.sendInnerMsg(MsgCfg_1.InnerMsg.gameResume);
        }
    };
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "btnClose", void 0);
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "btnSound", void 0);
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "btnMusic", void 0);
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "btnLoginOut", void 0);
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "btnGameOut", void 0);
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "btnResetPwd", void 0);
    __decorate([
        property(cc.SpriteFrame)
    ], NewClass.prototype, "chatSp", void 0);
    NewClass = __decorate([
        ccclass
    ], NewClass);
    return NewClass;
}(Lv_DialogView_1.default));
exports.default = NewClass;

cc._RF.pop();