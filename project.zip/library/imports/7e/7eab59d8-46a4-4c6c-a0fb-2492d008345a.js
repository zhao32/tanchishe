"use strict";
cc._RF.push(module, '7eab5nYRqRMbKD7JJLQCDRa', 'rechargeNode');
// scripts/rechargeNode.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var PromptFly_1 = require("./com/PromptFly");
var EventManager_1 = require("./LGQ/EventManager");
var GButton_1 = require("./LGQ/GButton");
var Lv_DialogView_1 = require("./LGQ/Lv_DialogView");
var UserInfo_1 = require("./LGQ/UserInfo");
var xhrSupport_1 = require("./LGQ/xhrSupport");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var NewClass = /** @class */ (function (_super) {
    __extends(NewClass, _super);
    function NewClass() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.btnClose = null;
        _this.btnRecharge = null;
        _this.editBpx = null;
        _this.box = null;
        _this.item = null;
        _this.coinFrames = [];
        _this.selectIdx = 0;
        _this.rechargeIdx = 0;
        _this.rechargeData = [];
        return _this;
        // update (dt) {}
    }
    // LIFE-CYCLE CALLBACKS:
    NewClass.prototype.onLoad = function () {
        window["gameCallFromiOS"] = this.gameCallFromiOS.bind(this);
        window["gameCallWithParams"] = this.gameCallWithParams.bind(this);
        if (cc.sys.platform == cc.sys.IPHONE) {
            // 初始化 iOS 内购
            jsb.reflection.callStaticMethod("IAPBridge", "initIAP", null);
            console.log("[IAP] iOS 内购已初始化");
        }
    };
    /**
     * iOS 调用的无参方法
     */
    NewClass.prototype.gameCallFromiOS = function () {
        console.log("iOS 调用了 Cocos 的无参方法");
        // 业务逻辑：如显示弹窗、播放音效等
    };
    /**
     * iOS 调用的带参数方法（支持多参数、复杂对象）
     */
    NewClass.prototype.gameCallWithParams = function (receipt_data, order_sn) {
        var _this = this;
        console.log("iOS 传参：", receipt_data, order_sn);
        // 业务逻辑：如更新UI、处理数据等
        xhrSupport_1.default.RechargeCheck(receipt_data, order_sn, function (res) {
            res = JSON.parse(res);
            if (res.code == 1) {
                UserInfo_1.default.userInfo.score += _this.rechargeData[_this.rechargeIdx].score;
                EventManager_1.default.getInstance().sendListener(EventManager_1.default.UPDATE_SCORE);
                _this.closeView();
            }
            PromptFly_1.default.Show(res.msg);
        }, function () { });
    };
    /**
     * （可选）有返回值的方法（iOS 可获取返回值）
     */
    NewClass.prototype.gameCallWithReturn = function () {
        return "Cocos 返回给 iOS 的数据";
    };
    NewClass.prototype.start = function () {
        var _this = this;
        this.editBpx.node.active = false;
        GButton_1.default.AddClick(this.btnClose, this.closeView, this);
        GButton_1.default.AddClick(this.btnRecharge, this.onRechargeClick, this);
        xhrSupport_1.default.getRechargeList(function (res) {
            res = JSON.parse(res);
            if (res.code == 1) {
                _this.rechargeData = res.data.list;
                var _loop_1 = function (i) {
                    var item = cc.instantiate(_this.item);
                    item.parent = _this.box;
                    item.active = true;
                    item.y = 0;
                    if (i == 0) {
                        item.getChildByName("checkmark").active = true;
                    }
                    else {
                        item.getChildByName("checkmark").active = false;
                    }
                    var idx = i > 2 ? 2 : i;
                    item.getChildByName("coin").getComponent(cc.Sprite).spriteFrame = _this.coinFrames[idx];
                    item.getChildByName("prizeLabel").getComponent(cc.Label).string = res.data.list[i].price;
                    item.getChildByName("scoreLabel").getComponent(cc.Label).string = res.data.list[i].score;
                    // item.getComponent("rechargeItem").init(res.data.list[i]);
                    item.on(cc.Node.EventType.TOUCH_END, function () {
                        for (var j = 0; j < _this.box.children.length; j++) {
                            _this.box.children[j].getChildByName("checkmark").active = false;
                        }
                        item.getChildByName("checkmark").active = true;
                        _this.rechargeIdx = i;
                    }, _this);
                };
                for (var i = 0; i < res.data.list.length; i++) {
                    _loop_1(i);
                }
            }
            else {
                PromptFly_1.default.Show(res.msg);
            }
        }, function () { });
    };
    // 点击充值按钮
    NewClass.prototype.onRechargeClick = function () {
        var _this = this;
        var productId = this.rechargeData[this.rechargeIdx].id;
        // 映射到 Apple 的产品ID
        var appleProductId = this.getAppleProductId(productId);
        xhrSupport_1.default.doRecharge(productId, "applepay", function (res) {
            res = JSON.parse(res);
            if (res.code == 1) {
                _this.payment({
                    appleProductId: appleProductId, orderSn: res.data.data.order_sn,
                    success: function (data) {
                        // console.log('data', data);
                    }
                });
            }
            else {
                PromptFly_1.default.Show(res.msg);
            }
        }, function () { });
    };
    /**
     * 支付
     * {
     *   provider: 'wxpay' | alipay, // app 必填
     *   data: '',
     * }
     */
    NewClass.prototype.payment = function (data) {
        console.log('ios支付', JSON.stringify(data));
        if (cc.sys.platform == cc.sys.IPHONE) {
            // 获取服务器返回的数据
            var orderSn = data.orderSn; // 订单号
            var appleProductId = data.appleProductId;
            console.log("[IAP] \u5F00\u59CB\u5185\u8D2D: \u8BA2\u5355=" + orderSn + ", Apple\u4EA7\u54C1=" + appleProductId);
            // 调用 iOS 原生方法发起购买
            jsb.reflection.callStaticMethod("IAPBridge", "purchaseProduct:orderSn:", appleProductId, // Apple 商品 ID
            orderSn // 订单号
            );
        }
        else if (cc.sys.platform == cc.sys.BYTEDANCE_GAME) {
        }
        else if (cc.sys.platform == cc.sys.WECHAT_GAME) {
        }
        else {
            if (data === null || data === void 0 ? void 0 : data.success)
                data.success();
        }
    };
    // 3️⃣ Apple 产品 ID 映射表
    NewClass.prototype.getAppleProductId = function (productId) {
        // 将你服务器的产品ID映射到 App Store Connect 的商品ID
        var productMap = {
            '1': 'com.gameios.bztcs.app.gold01',
            '2': 'com.gameios.bztcs.app.gold02',
            '3': 'com.gameios.bztcs.app.gold03',
            '4': 'com.gameios.bztcs.app.gold04',
        };
        return productMap[productId] || 'com.yourcompany.yourapp.default';
    };
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "btnClose", void 0);
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "btnRecharge", void 0);
    __decorate([
        property(cc.EditBox)
    ], NewClass.prototype, "editBpx", void 0);
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "box", void 0);
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "item", void 0);
    __decorate([
        property(cc.SpriteFrame)
    ], NewClass.prototype, "coinFrames", void 0);
    NewClass = __decorate([
        ccclass
    ], NewClass);
    return NewClass;
}(Lv_DialogView_1.default));
exports.default = NewClass;

cc._RF.pop();