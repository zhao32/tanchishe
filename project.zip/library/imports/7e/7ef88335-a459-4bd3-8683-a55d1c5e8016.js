"use strict";
cc._RF.push(module, '7ef88M1pFlL04aDpV0cXoAW', 'skinItem');
// scripts/skinItem.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var PromptFly_1 = require("./com/PromptFly");
var EventManager_1 = require("./LGQ/EventManager");
var UserInfo_1 = require("./LGQ/UserInfo");
var xhrSupport_1 = require("./LGQ/xhrSupport");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var NewClass = /** @class */ (function (_super) {
    __extends(NewClass, _super);
    function NewClass() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.nameLabel = null;
        _this.priceLabel = null;
        _this.stateLabel = null;
        _this.iconSprite = null;
        _this.btnBuy = null;
        _this.btnUse = null;
        return _this;
        // onSelct() {
        //     this.btnUse.active = true
        //     this.useState.active = false
        //     this._data.use_status = 1
        // }
        // unSelect() {
        //     this.btnUse.active = false
        //     this.useState.active = true
        //     this._data.use_status = 0
        // }
        // update (dt) {}
    }
    // onLoad () {}
    NewClass.prototype.start = function () {
    };
    NewClass.prototype.init = function (data) {
        var _this = this;
        this._data = data;
        this.nameLabel.string = data.name;
        if (data.is_have) {
            this.btnBuy.active = false;
            this.priceLabel.node.parent.active = false;
            if (data.use_status) {
                this.btnUse.active = false;
                // this.useState.active = true
                this.stateLabel.string = "使用中";
            }
            else {
                this.btnUse.active = true;
                // this.useState.active = false
                this.stateLabel.string = "已拥有";
            }
        }
        else {
            // this.useState.active = false
            this.priceLabel.node.parent.active = true;
            this.btnBuy.active = true;
            this.btnUse.active = false;
            this.priceLabel.string = data.price;
            this.stateLabel.string = "";
        }
        cc.assetManager.loadRemote(xhrSupport_1.default.httpUrl + data.cover_image, function (err, texture) {
            if (err) {
                cc.error(err.message || err);
                return;
            }
            else {
                _this.iconSprite.spriteFrame = new cc.SpriteFrame(texture);
            }
        });
        // cc.assetManager.loadRemote(xhrSupport.httpUrl + data.scenc_image, (err, texture: any) => {
        //     if (err) {
        //         cc.error(err.message || err);
        //         return;
        //     } else {
        //         this.node.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(texture);
        //     }
        // })
    };
    NewClass.prototype.onBuySkin = function () {
        var _this = this;
        xhrSupport_1.default.buySkin(this._data.id, function (res) {
            res = JSON.parse(res);
            if (res.code == 1) {
                _this._data.is_have = true;
                _this.btnBuy.active = false;
                _this.btnUse.active = true;
                _this.priceLabel.node.parent.active = false;
                UserInfo_1.default.userInfo.score -= _this._data.price;
                EventManager_1.default.getInstance().sendListener(EventManager_1.default.UPDATE_SCORE, _this._data.id);
            }
            else {
                PromptFly_1.default.Show(res.msg);
            }
        }, function () { });
    };
    NewClass.prototype.onUseSkin = function () {
        var _this = this;
        xhrSupport_1.default.useSkin(this._data.id, function (res) {
            res = JSON.parse(res);
            if (res.code == 1) {
                UserInfo_1.default.userInfo.skinId = _this._data.id;
                // this.btnUse.active = false
                // this.useState.active = true
                EventManager_1.default.getInstance().sendListener(EventManager_1.default.CHANGE_SKIN, _this._data.id);
                //更新列表
            }
            else {
                PromptFly_1.default.Show(res.msg);
            }
        }, function () { });
    };
    __decorate([
        property(cc.Label)
    ], NewClass.prototype, "nameLabel", void 0);
    __decorate([
        property(cc.Label)
    ], NewClass.prototype, "priceLabel", void 0);
    __decorate([
        property(cc.Label)
    ], NewClass.prototype, "stateLabel", void 0);
    __decorate([
        property(cc.Sprite)
    ], NewClass.prototype, "iconSprite", void 0);
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "btnBuy", void 0);
    __decorate([
        property(cc.Node)
    ], NewClass.prototype, "btnUse", void 0);
    NewClass = __decorate([
        ccclass
    ], NewClass);
    return NewClass;
}(cc.Component));
exports.default = NewClass;

cc._RF.pop();