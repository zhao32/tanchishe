"use strict";
cc._RF.push(module, 'a1ce68anXNNqLZCOUvoeIRa', 'CameraFollow');
// scripts/CameraFollow.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var CameraFollow = /** @class */ (function (_super) {
    __extends(CameraFollow, _super);
    function CameraFollow() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.ndBG = null;
        _this.ndCanvas = null;
        _this.isMove = true;
        _this.target = null;
        _this.offsetX = 0;
        _this.smoothSpeed = 1;
        return _this;
        // protected lateUpdate(dt: number): void {
        //     if (!this.target) return;
        //     if (!this.isMove) return;
        //     // 计算目标位置
        //     const targetPosition = this.target.position; //.add(cc.v3(this.offsetX, 0));
        //     if (targetPosition.x + this.ndCanvas.width / 2 > this.ndBG.height / 2) {
        //         targetPosition.x = this.ndBG.height / 2 - this.ndCanvas.width / 2;
        //     }
        //     if (targetPosition.x - this.ndCanvas.width / 2 < -this.ndBG.height / 2) {
        //         targetPosition.x = -(this.ndBG.height / 2 - this.ndCanvas.width / 2);
        //     }
        //     if (targetPosition.y + this.ndCanvas.height / 2 > this.ndBG.width / 2) {
        //         targetPosition.y = this.ndBG.width / 2 - this.ndCanvas.height / 2;
        //     }
        //     if (targetPosition.y - this.ndCanvas.height / 2 < -this.ndBG.width / 2) {
        //         targetPosition.y = -(this.ndBG.width / 2 - this.ndCanvas.height / 2);
        //     }
        //     // 平滑移动摄像机
        //     // let newPosition = this.node.position.lerp(targetPosition, this.smoothSpeed);
        //     // newPosition.y = 0;
        //     this.node.position = targetPosition;
        // }
    }
    CameraFollow.prototype.onLoad = function () { };
    CameraFollow.prototype.start = function () {
        // cc.log("数据111111111", this.ndCanvas.width, this.ndCanvas.height);
    };
    CameraFollow.prototype.resetMove = function () {
        this.target = null;
        this.isMove = false;
        this.node.setPosition(cc.v2(0, 0));
    };
    CameraFollow.prototype.startMove = function () {
        this.isMove = true;
    };
    CameraFollow.prototype.update = function (dt) {
        // if (!this.target) return;
        // if (!this.isMove) return;
        // // 计算目标位置
        // const targetPosition = this.target.position; //.add(cc.v3(this.offsetX, 0));
        // if (targetPosition.x + this.ndCanvas.width / 2 > this.ndBG.height / 2) {
        //     targetPosition.x = this.ndBG.height / 2 - this.ndCanvas.width / 2;
        // }
        // if (targetPosition.x - this.ndCanvas.width / 2 < -this.ndBG.height / 2) {
        //     targetPosition.x = -(this.ndBG.height / 2 - this.ndCanvas.width / 2);
        // }
        // if (targetPosition.y + this.ndCanvas.height / 2 > this.ndBG.width / 2) {
        //     targetPosition.y = this.ndBG.width / 2 - this.ndCanvas.height / 2;
        // }
        // if (targetPosition.y - this.ndCanvas.height / 2 < -this.ndBG.width / 2) {
        //     targetPosition.y = -(this.ndBG.width / 2 - this.ndCanvas.height / 2);
        // }
        // // 平滑移动摄像机
        // // let newPosition = this.node.position.lerp(targetPosition, this.smoothSpeed);
        // // newPosition.y = 0;
        // this.node.position = targetPosition;
        // let nX = this.node.convertToWorldSpaceAR(cc.v2(0, 0));
        // let endX = this.endMap.convertToWorldSpaceAR(cc.v2(0, 0));
        // if (Math.floor(nX.x) >= Math.floor(endX.x)) {
        //     let pos = this.node.parent.convertToNodeSpaceAR(endX)
        //     this.node.setPosition(pos);
        //     this.isMove = false;
        //     // GameNode.I.gameOver();
        // }
    };
    CameraFollow.prototype.lateUpdate = function (dt) {
        if (!this.target)
            return;
        if (!this.isMove)
            return;
        // 计算目标位置
        var targetPosition = this.target.position; //.add(cc.v3(this.offsetX, 0));
        if (targetPosition.x + this.ndCanvas.width / 2 > this.ndBG.width / 2) {
            targetPosition.x = this.ndBG.width / 2 - this.ndCanvas.width / 2;
        }
        if (targetPosition.x - this.ndCanvas.width / 2 < -this.ndBG.width / 2) {
            targetPosition.x = -(this.ndBG.width / 2 - this.ndCanvas.width / 2);
        }
        if (targetPosition.y + this.ndCanvas.height / 2 > this.ndBG.height / 2) {
            targetPosition.y = this.ndBG.height / 2 - this.ndCanvas.height / 2;
        }
        if (targetPosition.y - this.ndCanvas.height / 2 < -this.ndBG.height / 2) {
            targetPosition.y = -(this.ndBG.height / 2 - this.ndCanvas.height / 2);
        }
        // 平滑移动摄像机
        // let newPosition = this.node.position.lerp(targetPosition, this.smoothSpeed);
        // newPosition.y = 0;
        this.node.position = targetPosition;
    };
    __decorate([
        property(cc.Node)
    ], CameraFollow.prototype, "ndBG", void 0);
    __decorate([
        property(cc.Node)
    ], CameraFollow.prototype, "ndCanvas", void 0);
    CameraFollow = __decorate([
        ccclass
    ], CameraFollow);
    return CameraFollow;
}(cc.Component));
exports.default = CameraFollow;

cc._RF.pop();