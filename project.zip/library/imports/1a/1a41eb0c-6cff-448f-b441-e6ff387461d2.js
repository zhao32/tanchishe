"use strict";
cc._RF.push(module, '1a41esMbP9Ej7RB5v84dGHS', 'monster');
// scripts/monster.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var Game_1 = require("./Game");
var Utils_1 = require("./LGQ/Utils");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var monster = /** @class */ (function (_super) {
    __extends(monster, _super);
    function monster() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.ndAni = null;
        _this.type = 0;
        _this.isMove = false;
        return _this;
    }
    monster.prototype.onLoad = function () {
        var pos = this.randomPos();
        this.node.setPosition(pos);
    };
    monster.prototype.start = function () {
        // this.ndAni.timeScale = 0;
        // // this.ndAni.clearTrack(0);
        // if (!Game.I.isPause) {
        //     this.isMove = true;
        //     // this.ndAni.setAnimation(0, 'newAnimation', true);
        //     this.ndAni.timeScale = 1;
        //     // this.setMove();
        // }
    };
    monster.prototype.randomPos = function () {
        var width = this.node.parent.width;
        var height = this.node.parent.height;
        var x = Math.round(Math.random() * width) - width / 2;
        var y = Math.round(Math.random() * height) - height / 2;
        if (x <= -(width / 2 + this.node.width * 2)) {
            x = -(width / 2 + this.node.width * 2);
        }
        if (y <= -(height / 2 + this.node.height * 2)) {
            y = -(height / 2 + this.node.height * 2);
        }
        if (x >= (width / 2 - this.node.width * 2)) {
            x = width / 2 - this.node.width * 2;
        }
        if (y > (height / 2 - this.node.height * 2)) {
            y = height / 2 - this.node.height * 2;
        }
        var pos = cc.v2(x, y);
        if (Utils_1.Utils.getDistance(Game_1.default.I.player.getPosition(), pos) <= 200) {
            pos = this.randomPos();
        }
        return cc.v2(x, y);
    };
    monster.prototype.setMove = function () {
        var _this = this;
        var width = this.node.parent.width;
        var height = this.node.parent.height;
        var x = Math.round(Math.random() * width) - width / 2;
        var y = Math.round(Math.random() * height) - height / 2;
        var pos = cc.v2(x, y);
        var _p = pos.sub(cc.v2(this.node.position.x, this.node.position.y));
        var angle = cc.v2(1, 0).signAngle(_p.normalize()) * 180 / Math.PI;
        // this.node.angle = angle-90;
        if (this.type == 1) {
            this.node.angle = angle;
        }
        else {
            this.node.angle = angle - 90;
        }
        var speed = Math.random() * 1 + 2;
        var time = Utils_1.Utils.getDistance(this.node.position, pos) / speed / 60;
        cc.tween(this.node)
            .to(time, { position: new cc.Vec3(pos.x, pos.y) })
            .call(function () {
            _this.setMove();
        })
            .start();
    };
    monster.prototype.gamePause = function () {
        // this.ndAni.timeScale = 0;
        // cc.Tween.stopAllByTarget(this.node);
        // // cc.tween(this.node).stop().start();
    };
    monster.prototype.gameResume = function () {
        // this.ndAni.timeScale = 1;
        // this.setMove();
    };
    monster.prototype.update = function (dt) {
        // if (!Game.I.isPause && !this.isMove) {
        //     this.isMove = true;
        //     this.ndAni.timeScale = 1;
        //     this.setMove();
        // }
    };
    __decorate([
        property(sp.Skeleton)
    ], monster.prototype, "ndAni", void 0);
    __decorate([
        property()
    ], monster.prototype, "type", void 0);
    monster = __decorate([
        ccclass
    ], monster);
    return monster;
}(cc.Component));
exports.default = monster;

cc._RF.pop();